import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = ts.transpileModule(readFileSync(new URL('../src/lib/notifications.ts', import.meta.url), 'utf8'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
}).outputText;
const { getNotificationPanelRecords, getNotificationTabCounts, setNotificationStatus } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const session = { email: 'user@example.com', roleNames: ['Accountant'] };
const row = (id, severity = 'Info', extra = {}) => ({
  id, category: 'notifications', status: 'Active', severity,
  organizationId: 'company-1', name: id, type: 'Documents', message: id,
  createdAt: '2026-10-28T10:00:00Z', ...extra,
});
const ids = rows => rows.map(item => item.id);

test('badge counts every active notification with no five-item cap', () => {
  const records = Array.from({ length: 12 }, (_, index) => row(`event-${index}`));
  records.push(row('resolved', 'Critical', { notificationStatus: 'Resolved' }));
  records.push(row('task', 'Critical', { category: 'reminders', taskStatus: 'Open' }));
  assert.equal(getNotificationTabCounts(records, session).notifications, 12);
  assert.equal(getNotificationPanelRecords(records, session).length, 5);
});

test('panel prioritizes only Critical and Warning, then newest in each group', () => {
  const records = [
    row('info-new', 'Info', { createdAt: '2026-10-28T12:00:00Z' }),
    row('warning-new', 'Warning', { createdAt: '2026-10-28T11:00:00Z' }),
    row('critical-old', 'Critical', { createdAt: '2026-10-28T08:00:00Z' }),
    row('critical-new', 'Critical', { createdAt: '2026-10-28T09:00:00Z' }),
    row('warning-old', 'Warning'),
  ];
  assert.deepEqual(ids(getNotificationPanelRecords(records, session)), ['critical-new', 'critical-old', 'warning-new', 'warning-old']);
  assert.equal(getNotificationTabCounts(records, session).notifications, 5);
});

test('when no priority alert remains active, other active notifications appear newest first', () => {
  const records = [
    row('info-old', 'Info', { createdAt: '2026-10-28T08:00:00Z' }),
    row('info-new', 'Info', { outcome: 'success' }),
    row('legacy', undefined, { severity: undefined, createdAt: '2026-10-28T09:00:00Z' }),
    row('critical', 'Critical'),
    row('warning-resolved', 'Warning', { resolvedAt: '2026-10-28T11:00:00Z' }),
  ];
  assert.deepEqual(ids(getNotificationPanelRecords(records, session)), ['critical']);
  const resolved = records.map(item => item.id === 'critical' ? setNotificationStatus(item, 'Resolved') : item);
  assert.deepEqual(ids(getNotificationPanelRecords(resolved, session)), ['info-new', 'legacy', 'info-old']);
  assert.equal(getNotificationTabCounts(resolved, session).notifications, 3);
});

test('reading does not hide an Active record and legacy status uses the same count rules', () => {
  const records = [
    row('read', 'Warning', { readAtByEmail: { [session.email]: '2026-10-28T10:01:00Z' } }),
    row('explicit-active', 'Info', { status: 'Inactive', notificationStatus: 'Active' }),
    row('inactive', 'Critical', { status: 'Inactive' }),
  ];
  assert.equal(getNotificationTabCounts(records, session).notifications, 2);
  assert.deepEqual(ids(getNotificationPanelRecords(records, session)), ['read']);
});

test('count and preview share recipient and role filters and de-duplicate the same event', () => {
  const info = row('visible');
  const records = [info, { ...info },
    row('other-recipient', 'Critical', { recipientEmails: ['other@example.com'] }),
    row('other-role', 'Warning', { relevantRoles: ['Administrator'] }),
    row('other-organization-event', 'Info', { id: 'visible', organizationId: 'company-2' }),
  ];
  assert.equal(getNotificationTabCounts(records, session).notifications, 2);
  assert.equal(getNotificationPanelRecords(records, session).length, 2);
});

test('priority preview stays capped at five without filling spare slots with Info', () => {
  const records = Array.from({ length: 7 }, (_, index) => row(`critical-${index}`, 'Critical'));
  assert.equal(getNotificationPanelRecords(records, session).length, 5);
  assert.deepEqual(ids(getNotificationPanelRecords([records[0], row('info')], session)), ['critical-0']);
});

test('no Active notifications produces an empty panel and zero count', () => {
  const records = [row('resolved', 'Critical', { notificationStatus: 'Resolved' })];
  assert.deepEqual(getNotificationPanelRecords(records, session), []);
  assert.equal(getNotificationTabCounts(records, session).notifications, 0);
});

test('Dashboard uses the shared preview and exact Active count for both badges', () => {
  const dashboard = readFileSync(new URL('../src/components/Dashboard.tsx', import.meta.url), 'utf8');
  assert.match(dashboard, /activeNotificationCount = notificationCounts\.notifications/);
  assert.match(dashboard, /activeNotificationBadge = String\(activeNotificationCount\)/);
  assert.match(dashboard, /recentNotifications = getNotificationPanelRecords\(visibleNotifications\.records/);
  assert.equal((dashboard.match(/\{activeNotificationBadge\}/g) ?? []).length, 2);
  assert.doesNotMatch(dashboard, /filter\(isImportantNotification\)/);
});
