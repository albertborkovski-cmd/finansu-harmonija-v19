import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const compile = file => ts.transpileModule(readFileSync(new URL(file, import.meta.url), 'utf8'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
}).outputText;
const core = {};
new Function('exports', compile('../src/lib/ocrLearning.ts'))(core);
const memory = new Map();
Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: {
  getItem: key => memory.get(key) ?? null,
  setItem: (key, value) => memory.set(key, value),
} });
globalThis.window = new EventTarget();
const fixture = { companies: [], documents: [], error: null, edit: true, admin: true };
const adapter = { from(table) {
  let rows = fixture[table] ?? [];
  return { select() { return this; }, eq(key, value) { rows = rows.filter(row => row[key] === value); return this; },
    in(key, values) { rows = rows.filter(row => values.includes(row[key])); return this; },
    then(resolve) { return Promise.resolve({ data: rows, error: fixture.error }).then(resolve); } };
} };
const store = {};
new Function('require', 'exports', compile('../src/lib/ocrLearningStore.ts'))(id => ({
  './currentUser': { AUTH_SESSION_KEY: 'auth', getCurrentUserIdentity: () => ({ fullName: 'Reviewer', email: 'reviewer@example.test' }) },
  './accessControl': { parseSession: () => ({ roleNames: fixture.admin ? ['Administrator'] : ['Accountant'] }), canEditMenu: () => fixture.edit, isSystemAdministratorRole: name => name === 'Administrator' },
  './supabase': { supabase: adapter },
  './ocrLearning': core,
})[id], store);
const document = id => ({ id, company_id: 'alice', client_counterparty: 'Northwind', counterparty_id: 'supplier-1',
  vat_percent: '21', file_case: `${id}.pdf`, number: id, expense_account: '6202', vat_classifier: 'PVM1' });
function reset() {
  memory.clear();
  store.persistLearningStore(core.emptyLearningStore());
  fixture.companies = [{ id: 'alice', name: 'Alice Stone' }, { id: 'bob', name: 'Bob Morris' }];
  fixture.documents = [document('one'), document('two')];
  fixture.error = null; fixture.edit = true; fixture.admin = true;
}

test('two approved documents teach both accounting fields and fill the next supplier document', async () => {
  reset();
  await store.recordReviewedOcrDocuments(['one']);
  let context = await store.documentLearningContext({ ...document('new'), expense_account: '', vat_classifier: '' });
  let proposed = store.suggestDocumentAccounting(context);
  assert.equal(proposed.expenseAccount, '');
  assert.match(proposed.explanations.expense_account, /Requires review/);
  await store.recordReviewedOcrDocuments(['two']);
  proposed = store.suggestDocumentAccounting(context);
  assert.equal(proposed.expenseAccount, '6202');
  assert.equal(proposed.vatClassifier, 'PVM1');
  assert.match(proposed.explanations.expense_account, /100% consistent · 2 of 2/);
  assert.equal(core.learnedRows(store.loadLearningStore())[0].total, 2);
  // Merely opening a new document did not teach it or increase the count.
  await store.recordReviewedOcrDocuments(['one', 'two']);
  assert.equal(core.learnedRows(store.loadLearningStore())[0].total, 2);
  const anotherCompany = store.suggestDocumentAccounting({ ...context, companyId: 'bob' });
  assert.equal(anotherCompany.expenseAccount, '');
  context = { ...context, expenseAccount: 'Manual account', vatClassifier: 'Manual VAT' };
  assert.equal(store.suggestDocumentAccounting(context).expenseAccount, 'Manual account');
});

test('persisted pause blocks future suggestions and resume rechecks the thresholds', async () => {
  reset();
  await store.recordReviewedOcrDocuments(['one', 'two']);
  const row = core.learnedRows(store.loadLearningStore()).find(row => row.field === 'expense_account');
  const context = await store.documentLearningContext({ ...document('new'), expense_account: '', vat_classifier: '' });
  assert.equal(store.changeLearningState(row.id, 'pause'), true);
  assert.equal(store.suggestDocumentAccounting(context).expenseAccount, '');
  assert.equal(store.suggestDocumentAccounting(context).vatClassifier, 'PVM1');
  assert.equal(store.changeLearningState(row.id, 'resume'), true);
  assert.equal(store.suggestDocumentAccounting(context).expenseAccount, '6202');
  assert.equal(store.changeLearningState(row.id, 'forget'), true);
  assert.equal(store.suggestDocumentAccounting(context).expenseAccount, '');
  assert.equal(fixture.documents.length, 2);
});

test('action permissions are rechecked on every mutation', async () => {
  reset();
  await store.recordReviewedOcrDocuments(['one', 'two']);
  const row = core.learnedRows(store.loadLearningStore())[0];
  fixture.admin = false;
  assert.equal(store.changeLearningState(row.id, 'forget'), false);
  assert.equal(store.changeLearningState(row.id, 'pause'), true);
  fixture.edit = false;
  const before = memory.get(store.OCR_LEARNING_KEY);
  assert.equal(store.changeLearningState(row.id, 'resume'), false);
  assert.equal(memory.get(store.OCR_LEARNING_KEY), before);
});

test('failed lookups cannot silently count as successful learning', async () => {
  reset();
  fixture.error = new Error('Unavailable');
  await assert.rejects(store.recordReviewedOcrDocuments(['one']), /Unavailable/);
  assert.equal(store.loadLearningStore().evidence.length, 0);
});

test('empty or damaged saved history is never reseeded with invented observations', () => {
  reset();
  assert.equal(store.loadLearningStore().evidence.length, 0);
  memory.set(store.OCR_LEARNING_KEY, '{broken');
  assert.equal(store.loadLearningStore().evidence.length, 0);
  assert.throws(() => store.confirmDocumentAccounting({ companyId: 'alice', supplierKey: 'supplier-1', documentId: 'new', expenseAccount: '6202', vatClassifier: 'PVM1' }));
  assert.equal(memory.get(store.OCR_LEARNING_KEY), '{broken');
});
