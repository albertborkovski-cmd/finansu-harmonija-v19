import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = readFileSync(new URL('../src/lib/reconciliationCombinedView.ts', import.meta.url), 'utf8');
const { outputText } = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } });
const module = { exports: {} };
new Function('exports', outputText)(module.exports);
const { reconciliationCombinedEntries, expandReconciliationRowSelection } = module.exports;
const items = ['payment', 'invoice1', 'invoice2', 'open-payment', 'open-invoice'].map(id => ({ id, remainingMinor: 10000 }));
const proposal = { id: 'proposal1', fundingId: 'payment', allocations: [{ invoiceId: 'invoice1', amountMinor: 2000 }, { invoiceId: 'invoice2', amountMinor: 3000 }] };

test('preserves Suggestions groups and adds unmatched open documents once', () => {
  const before = JSON.stringify(items);
  const entries = reconciliationCombinedEntries(items, [proposal]);
  assert.deepEqual(entries.map(entry => entry.id), ['proposal1', 'open-payment', 'open-invoice']);
  assert.equal(entries[0].proposal, proposal);
  assert.deepEqual(entries[0].itemIds, ['payment', 'invoice1', 'invoice2']);
  assert.equal(JSON.stringify(items), before, 'partial balances are never changed by grouping');
  assert.deepEqual(new Set(entries.flatMap(entry => entry.itemIds)), new Set(items.map(item => item.id)));
});

test('auto match expands selected proposal groups and keeps selection scoped', () => {
  const entries = reconciliationCombinedEntries(items, [proposal]);
  assert.deepEqual(expandReconciliationRowSelection(['proposal1', 'open-invoice'], entries), ['payment', 'invoice1', 'invoice2', 'open-invoice']);
  assert.deepEqual(expandReconciliationRowSelection(['open-payment'], entries), ['open-payment']);
  assert.deepEqual(expandReconciliationRowSelection([], entries), []);
});

test('invalid proposals do not hide available open documents', () => {
  const entries = reconciliationCombinedEntries(items, [{ ...proposal, fundingId: 'missing' }]);
  assert.deepEqual(entries.map(entry => entry.id), items.map(item => item.id));
});

test('without suggestions, every open item remains available; after confirmation only remaining items remain', () => {
  assert.equal(reconciliationCombinedEntries(items, []).length, items.length);
  const remaining = items.filter(item => ['payment', 'open-payment', 'open-invoice'].includes(item.id));
  assert.deepEqual(reconciliationCombinedEntries(remaining, []).map(entry => entry.id), remaining.map(item => item.id));
});
