import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const source = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const compiled = ts.transpileModule(source('../src/lib/ocrLearning.ts'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
}).outputText;
const { emptyLearningStore, confirmLearning, learnedRows, automaticLearningValue, setLearningPaused,
  forgetLatestLearning, createLearningExamples, normalizeVatRate } = await import(`data:text/javascript;base64,${Buffer.from(compiled).toString('base64')}`);
const context = { companyId: 'alice', companyName: 'Alice', supplierKey: '123', supplierName: 'Supplier', vatRate: '21' };
const actor = { name: 'Reviewer', email: 'reviewer@example.test' };
const entry = (documentId, value = '6202', overrides = {}) => ({ ...context, documentId, documentName: `${documentId}.pdf`,
  field: 'expense_account', value, confirmedAt: `2026-10-29T10:00:00.000Z`, confirmedBy: actor, ...overrides });
const teach = (values, overrides = {}) => values.reduce((store, value, i) => confirmLearning(store, entry(`doc-${i}`, value, overrides)), emptyLearningStore());

test('one confirmation is visible but does not qualify; two agreeing documents do', () => {
  let store = teach(['6202']);
  assert.equal(learnedRows(store)[0].status, 'Needs review');
  assert.equal(automaticLearningValue(store, context, 'expense_account'), undefined);
  store = confirmLearning(store, entry('second'));
  assert.equal(learnedRows(store)[0].status, 'Used automatically');
  assert.equal(automaticLearningValue(store, context, 'expense_account').value, '6202');
});

test('90% qualifies exactly; less than 90% leaves the field for review', () => {
  const good = teach([...Array(9).fill('6202'), '6300']);
  assert.equal(learnedRows(good)[0].consistency, 0.9);
  assert.equal(learnedRows(good)[0].status, 'Used automatically');
  const low = teach([...Array(8).fill('6202'), '6300']);
  assert.equal(learnedRows(low)[0].status, 'Needs review');
  assert.equal(automaticLearningValue(low, context, 'expense_account'), undefined);
});

test('competing values retain counts and an even split never fills automatically', () => {
  const row = learnedRows(teach(['6202', '6300', '6300', '6202']))[0];
  assert.deepEqual(row.candidates, [{ value: '6202', count: 2 }, { value: '6300', count: 2 }]);
  assert.equal(row.total, 4);
  assert.equal(row.status, 'Needs review');
});

test('reconfirming one document cannot inflate confidence', () => {
  const initial = confirmLearning(emptyLearningStore(), entry('one'));
  const repeated = confirmLearning(initial, entry('one', '6202', { confirmedAt: '2026-10-30T10:00:00.000Z' }));
  assert.equal(initial, repeated);
  assert.equal(learnedRows(repeated)[0].total, 1);
  assert.equal(repeated.audit.length, 1);
});

test('changing a confirmed value retires old evidence and preserves the audit trail', () => {
  const initial = teach(['6202', '6202']);
  const corrected = confirmLearning(initial, entry('doc-0', '6300', { confirmedAt: '2026-10-30T10:00:00.000Z' }));
  const row = learnedRows(corrected)[0];
  assert.equal(row.total, 2);
  assert.equal(row.consistency, 0.5);
  assert.equal(row.evidence.length, 3);
  assert.equal(row.evidence.filter(item => !item.active)[0].retirementReason, 'Corrected');
  assert.equal(corrected.audit.length, 3);
  assert.equal(initial.evidence.every(item => item.active), true);
});

test('companies, VAT rates and fields are isolated and normalized', () => {
  const store = teach(['6202', '6202']);
  assert.ok(automaticLearningValue(store, { ...context, vatRate: '21.00%' }, 'expense_account'));
  assert.equal(automaticLearningValue(store, { ...context, companyId: 'bob' }, 'expense_account'), undefined);
  assert.equal(automaticLearningValue(store, { ...context, vatRate: '0' }, 'expense_account'), undefined);
  assert.equal(automaticLearningValue(store, context, 'vat_classifier'), undefined);
  assert.equal(normalizeVatRate(''), '');
});

test('pause applies to the whole company/supplier/field, including every VAT-rate group', () => {
  let store = teach(['6202', '6202']);
  for (let i = 0; i < 2; i++) store = confirmLearning(store, entry(`zero-${i}`, '6300', { vatRate: '0' }));
  const paused = setLearningPaused(store, learnedRows(store)[0], true, actor, '2026-10-30T10:00:00.000Z');
  assert.equal(learnedRows(paused).every(row => row.status === 'Paused'), true);
  assert.equal(automaticLearningValue(paused, context, 'expense_account'), undefined);
  assert.equal(automaticLearningValue(paused, { ...context, vatRate: '0' }, 'expense_account'), undefined);
  assert.equal(paused.audit.at(-1).action, 'Paused');
  assert.equal(paused.audit.at(-1).actor.name, actor.name);
  const resumed = setLearningPaused(paused, learnedRows(paused)[0], false, actor, '2026-10-30T11:00:00.000Z');
  assert.equal(learnedRows(resumed).every(row => row.status === 'Used automatically'), true);
  assert.equal(resumed.audit.at(-1).action, 'Resumed');
});

test('forgetting requires admin, excludes only the newest source and recalculates confidence', () => {
  let store = confirmLearning(emptyLearningStore(), entry('older'));
  store = confirmLearning(store, entry('newest', '6202', { confirmedAt: '2026-10-30T10:00:00.000Z' }));
  const id = learnedRows(store)[0].id;
  assert.equal(forgetLatestLearning(store, id, actor, 'now', false), store);
  const forgotten = forgetLatestLearning(store, id, actor, '2026-10-31T10:00:00.000Z', true);
  assert.equal(forgotten.evidence.length, 2);
  assert.equal(forgotten.evidence.find(item => item.documentId === 'newest').active, false);
  assert.equal(learnedRows(forgotten)[0].status, 'Needs review');
  assert.equal(forgotten.audit.at(-1).action, 'Forgotten');
  const inactive = forgetLatestLearning(forgotten, id, actor, '2026-10-31T11:00:00.000Z', true);
  assert.equal(learnedRows(inactive)[0].status, 'Inactive');
  assert.equal(learnedRows(inactive)[0].evidence.length, 2);
});

test('changing supplier or VAT rate moves the document without counting it twice', () => {
  const store = teach(['6202']);
  const moved = confirmLearning(store, entry('doc-0', '6202', { supplierKey: 'other', vatRate: '0' }));
  assert.equal(learnedRows(moved).reduce((count, row) => count + row.total, 0), 1);
  assert.equal(learnedRows(moved).find(row => row.supplierKey === '123').status, 'Inactive');
});

test('examples illustrate both threshold outcomes but never supply real auto-fill values', () => {
  const store = createLearningExamples();
  const rows = learnedRows(store);
  assert.equal(rows.length, 5);
  assert.ok(rows.some(row => row.consistency === 0.9 && row.status === 'Used automatically'));
  assert.ok(rows.some(row => row.consistency === 0.6 && row.status === 'Needs review'));
  assert.ok(rows.some(row => row.total === 1 && row.status === 'Needs review'));
  for (const row of rows) assert.equal(automaticLearningValue(store, row, row.field), undefined);
});

test('incomplete teaching records are not recorded', () => {
  for (const invalid of [{ value: '' }, { companyId: '' }, { supplierKey: '' }, { documentId: '' }]) {
    const store = emptyLearningStore();
    assert.equal(confirmLearning(store, entry('doc', '6202', invalid)), store);
  }
});

test('review integration teaches only confirmed documents and waits before opening the next', () => {
  const workspace = source('../src/components/WorkspaceView.tsx');
  assert.match(workspace, /nextTask.status === 'Completed' && nextTask.accounting/);
  assert.match(workspace, /confirmDocumentAccounting\(context\)/);
  assert.match(workspace, /suggestDocumentAccounting\(context\)/);
  assert.match(workspace, /await saveDocumentTask\(nextTask\);\s*onNextFile\(\)/);
  assert.match(source('../src/components/OcrReviewView.tsx'), /await recordReviewedOcrDocuments/);
});
