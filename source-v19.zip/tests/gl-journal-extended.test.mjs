import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const urls = new Map();
function moduleUrl(name) {
  if (urls.has(name)) return urls.get(name);
  const source = ts.transpileModule(readFileSync(new URL(`../src/lib/${name}.ts`, import.meta.url), 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText
    .replace(/from ['"]\.\/([^'"]+)['"]/g, (_, dependency) => `from '${moduleUrl(dependency)}'`);
  const url = `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
  urls.set(name, url); return url;
}
const { createSampleJournalRows, journalMatchesPeriod, journalWorkingRows } = await import(moduleUrl('glJournal'));
const { applyJournalDocumentAnalytics, journalDocumentAnalytics, emptyJournalLine, copyJournalDraft, editJournalDraft, saveJournalDraft, loadJournalDrafts, journalDraftRows, mergeJournalRows, updateJournalDraft, journalDraftStorageKey } = await import(moduleUrl('glJournalDrafts'));
const { deactivateJournalDocument } = await import(moduleUrl('glJournalLifecycle'));
const { journalVatMovements, journalVatEmail, journalMailto, journalVatCalculation } = await import(moduleUrl('glJournalVatEmail'));
const { VAT_EMAIL_TEMPLATES, renderVatTemplate, validateVatTemplate } = await import(moduleUrl('vatEmailTemplates'));
const rows = createSampleJournalRows('alice');
const accounts = [...new Map(rows.map(row => [row.account, { code: row.account, name: row.accountName }])).values()];
const active = new Set(accounts.map(account => account.code));
const context = { companyId: 'alice', mode: 'test', id: 'new-id', createdAt: '2026-10-12T10:00:00Z', createdBy: 'Test accountant' };
const changes = { ...context, expectedRevision: 0, changedAt: '2026-10-12T11:00:00Z', changedBy: 'Other accountant' };
function storage() { const values = new Map(); return { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) }; }
const copy = () => copyJournalDraft(rows, rows[0].document.id, 'BZ-2026-0001', '2026-10-12');

test('legacy line-level dimensions remain readable without changing existing stored history', () => {
  const s = storage(); const draft = copy();
  Object.assign(draft.lines[0], { object: 'Office', department: 'Accounting', employee: 'Employee A', vehicle: 'ABC 123' });
  const saved = saveJournalDraft(s, context, draft, accounts, []);
  const mapped = journalDraftRows([saved], active);
  for (const key of ['object', 'department', 'employee', 'vehicle']) assert.equal(mapped[0][key], draft.lines[0][key]);
  assert.equal(mapped[0].createdBy, 'Test accountant');
  const edit = editJournalDraft(mapped, saved.id); edit.lines[1].department = 'Sales';
  const updated = updateJournalDraft(s, changes, edit, accounts, rows);
  assert.equal(updated.createdBy, context.createdBy); assert.equal(updated.updatedBy, changes.changedBy);
  assert.equal(updated.lines[0].department, 'Accounting'); assert.equal(updated.lines[1].department, 'Sales');
  assert.equal(loadJournalDrafts(s, 'alice', 'test')[0].lines[0].vehicle, 'ABC 123');
});

test('document dimensions apply to every GL line, including new lines, and survive save/edit/copy', () => {
  const s = storage();
  const values = { object: 'Office', department: 'Accounting', employee: 'Employee A', vehicle: 'ABC 123' };
  const original = copy();
  const draft = applyJournalDocumentAnalytics(original, values);
  assert.notEqual(draft.lines[0], original.lines[0]);
  const saved = saveJournalDraft(s, context, draft, accounts, []);
  assert.deepEqual(saved.documentAnalytics, values);
  assert.ok(journalDraftRows(loadJournalDrafts(s, 'alice', 'test'), active).every(row => Object.keys(values).every(key => row[key] === values[key])));
  const edit = editJournalDraft(journalDraftRows([saved], active), saved.id);
  assert.deepEqual(journalDocumentAnalytics(edit), { values, conflicts: [] });
  edit.lines.push({ ...emptyJournalLine('added-debit'), account: '2441', debit: '10' }, { ...emptyJournalLine('added-credit'), account: '4484', credit: '10' });
  const cleared = { ...values, vehicle: '' };
  const updated = updateJournalDraft(s, changes, applyJournalDocumentAnalytics(edit, cleared), accounts, rows);
  assert.ok(updated.lines.every(line => line.vehicle === '' && line.department === values.department));
  const copied = copyJournalDraft(journalDraftRows([updated], active), saved.id, 'NEW-COPY', '2026-10-12');
  assert.deepEqual(journalDocumentAnalytics(copied), { values: cleared, conflicts: [] });
});

test('conflicting legacy dimensions require a document-wide choice and editor has one shared field set', () => {
  const draft = copy();
  draft.lines[0].department = 'Accounting'; draft.lines[1].department = 'Sales';
  const dimensions = journalDocumentAnalytics(draft);
  assert.ok(dimensions.conflicts.includes('department'));
  assert.equal(dimensions.values.department, '');
  const resolved = applyJournalDocumentAnalytics(draft, { ...dimensions.values, department: 'Operations' });
  assert.deepEqual(journalDocumentAnalytics(resolved).conflicts, []);
  const editor = readFileSync(new URL('../src/components/GlJournalEntryEditor.tsx', import.meta.url), 'utf8');
  assert.match(editor, /JOURNAL_ANALYTICS_KEYS\.map\(key/);
  assert.match(editor, /controls=\{\{\s*\.\.\.dimensionControls/);
  assert.match(editor, /onSave\(applyJournalDocumentAnalytics\(draft, documentAnalytics.values\)\)/);
  const correspondence = editor.split('correspondence={<>')[1];
  assert.doesNotMatch(correspondence, /JOURNAL_ANALYTICS_KEYS|\['object', 'department', 'employee', 'vehicle'\]/);
});

test('old saved entries without analytical fields remain readable and editable', () => {
  const s = storage(); const saved = saveJournalDraft(s, context, copy(), accounts, []);
  for (const line of saved.lines) for (const key of ['object', 'department', 'employee', 'vehicle']) delete line[key];
  s.setItem(journalDraftStorageKey('alice', 'test'), JSON.stringify([saved]));
  const mapped = journalDraftRows(loadJournalDrafts(s, 'alice', 'test'), active);
  const edit = editJournalDraft(mapped, saved.id);
  assert.equal(edit.lines[0].vehicle, ''); assert.equal(edit.lines[0].department, '');
});

test('deactivation preserves every line, identity, creator, amounts and journal history', () => {
  const s = storage(); const saved = saveJournalDraft(s, context, copy(), accounts, []);
  const originalRows = mergeJournalRows(rows, [saved], active);
  const inactive = deactivateJournalDocument(s, changes, originalRows);
  assert.equal(inactive.inactive, true); assert.equal(inactive.createdBy, context.createdBy);
  assert.equal(inactive.status, 'Draft'); assert.equal(inactive.number, saved.number);
  assert.deepEqual(inactive.lines, saved.lines); assert.equal(inactive.history.length, 1);
  const restored = mergeJournalRows(rows, loadJournalDrafts(s, 'alice', 'test'), active);
  assert.equal(restored.length, originalRows.length);
  assert.ok(restored.filter(row => row.document.id === saved.id).every(row => row.inactive));
  assert.equal(restored.filter(row => !row.inactive).length, rows.length);
  assert.throws(() => updateJournalDraft(s, { ...changes, expectedRevision: 1 }, copy(), accounts, rows), /Inactive/);
});

test('deactivation of a sample replaces only the same document, with no duplicated rows', () => {
  const s = storage(); const before = JSON.stringify(rows);
  const saved = deactivateJournalDocument(s, { ...changes, id: rows[0].document.id, expectedRevision: null }, rows);
  const merged = mergeJournalRows(rows, [saved], active);
  assert.equal(merged.length, rows.length); assert.deepEqual(merged.map(row => row.id), rows.map(row => row.id));
  assert.equal(saved.createdBy, rows[0].createdBy); assert.equal(saved.createdAt, rows[0].createdAt);
  assert.equal(JSON.stringify(rows), before);
  assert.equal(merged[0].posted, rows[0].posted);
  assert.ok(merged.filter(row => row.document.id === saved.id).every(row => row.inactive));
  assert.deepEqual(loadJournalDrafts(s, 'bob', 'test'), []); assert.deepEqual(loadJournalDrafts(s, 'alice', 'company'), []);
});

test('inactive entries stay visible in the working list without changing stored history', () => {
  const s = storage();
  const saved = deactivateJournalDocument(s, { ...changes, id: rows[0].document.id, expectedRevision: null }, rows);
  const before = s.getItem(journalDraftStorageKey('alice', 'test'));
  const merged = mergeJournalRows(rows, loadJournalDrafts(s, 'alice', 'test'), active);
  const visible = journalWorkingRows(merged);
  assert.ok(merged.some(row => row.document.id === saved.id));
  assert.ok(visible.some(row => row.document.id === saved.id && row.inactive));
  assert.equal(visible.length, rows.filter(row => !row.posted || row.balanced).length);
  assert.equal(s.getItem(journalDraftStorageKey('alice', 'test')), before);
  assert.deepEqual(journalWorkingRows([{ ...rows[0], inactive: true, posted: false }, { ...rows[1], posted: true, balanced: false }]), [{ ...rows[0], inactive: true, posted: false }]);
});

test('stale deactivate, corrupt storage and real source records cannot be silently overwritten', () => {
  const s = storage(); const saved = saveJournalDraft(s, context, copy(), accounts, []);
  updateJournalDraft(s, changes, editJournalDraft(journalDraftRows([saved], active), saved.id), accounts, rows);
  assert.throws(() => deactivateJournalDocument(s, changes, mergeJournalRows(rows, loadJournalDrafts(s, 'alice', 'test'), active)), /another window/);
  const before = s.getItem(journalDraftStorageKey('alice', 'test'));
  assert.throws(() => deactivateJournalDocument(s, { ...changes, id: 'missing', expectedRevision: null }, rows), /source document/);
  assert.equal(s.getItem(journalDraftStorageKey('alice', 'test')), before);
  assert.throws(() => deactivateJournalDocument(storage(), { ...changes, id: rows[0].document.id, mode: 'company', expectedRevision: null }, rows.map(row => ({ ...row, sample: false }))), /source document/);
});

test('GL account filter is exact, combines with inclusive from/to dates and never shows other accounts', () => {
  const filtered = rows.filter(row => journalMatchesPeriod(row, { from: '2026-09-01', to: '2026-09-30' }, '4430'));
  assert.ok(filtered.length > 1); assert.ok(filtered.every(row => row.account === '4430' && row.operationDate.startsWith('2026-09')));
  assert.ok(rows.filter(row => journalMatchesPeriod(row, { from: '', to: '' }, '4430')).length > filtered.length);
  assert.equal(journalMatchesPeriod({ ...rows[0], account: '44301' }, { from: '', to: '' }, '4430'), false);
  assert.equal(journalMatchesPeriod({ ...rows[0], operationDate: '—' }, { from: '2026-01-01', to: '' }), false);
  assert.equal(journalMatchesPeriod(rows[0], { from: rows[0].operationDate, to: rows[0].operationDate }), true);
});

test('VAT email uses posted active selected-account movements from the closing period, not the list filter', () => {
  const period = { from: '2026-09-01', to: '2026-09-30' };
  const changed = rows.map((row, index) => index % 4 === 0 ? { ...row, inactive: true } : row);
  const result = journalVatMovements(changed, period, ['2441', '4484', '2441']);
  const eligible = changed.filter(row => row.posted && !row.inactive && row.operationDate.startsWith('2026-09') && ['2441', '4484'].includes(row.account));
  assert.ok(result.length >= 2);
  for (const total of result) {
    const matching = eligible.filter(row => row.account === total.account && row.document.currency === total.currency);
    assert.equal(total.debitMinor, matching.reduce((sum, row) => sum + Math.round(row.debit * 100), 0));
    assert.equal(total.creditMinor, matching.reduce((sum, row) => sum + Math.round(row.credit * 100), 0));
  }
  assert.deepEqual(journalVatMovements(rows, { from: '', to: '' }, ['2441']), []);
  assert.deepEqual(journalVatMovements(rows, period, []), []);
});

test('mailto encodes a single recipient and all text without sending mail or marking it sent', () => {
  const email = journalVatEmail('Alice Stone', { from: '2026-09-01', to: '2026-09-30' }, ['2441', '4484'], rows);
  const href = journalMailto('finance@example.test', email.subject, email.body);
  const url = new URL(href);
  assert.equal(url.protocol, 'mailto:'); assert.equal(url.searchParams.get('body'), email.body);
  assert.match(email.body, /not a VAT declaration/); assert.match(email.body, /Currencies are shown separately/);
  assert.throws(() => journalMailto('invalid', email.subject, email.body));
  assert.throws(() => journalMailto('a@example.test?bcc=other@example.test', email.subject, email.body));
  assert.throws(() => journalMailto('a@example.test\r\nBcc:b@example.test', email.subject, email.body));
});

test('VAT reconciliation can ask for confirmation or inform the client with the selected period and personal message', () => {
  const period = { from: '2026-09-01', to: '2026-09-30' };
  const confirmation = journalVatEmail('Alice Stone', period, ['2441', '4484'], rows, { purpose: 'confirmation', contactName: 'Aurika', message: 'Please also send the missing invoice.' });
  assert.match(confirmation.subject, /confirmation requested/);
  assert.match(confirmation.body, /Hello Aurika,/);
  assert.match(confirmation.body, /reply to confirm whether it agrees/);
  assert.match(confirmation.body, /2026-09-01 — 2026-09-30/);
  assert.match(confirmation.body, /Please also send the missing invoice\./);
  const information = journalVatEmail('Alice Stone', period, ['2441', '4484'], rows, { purpose: 'information' });
  assert.match(information.subject, /VAT reconciliation information/);
  assert.doesNotMatch(information.subject, /confirmation requested/);
  assert.match(information.body, /Please find the VAT account summary/);
  assert.deepEqual(information.totals, confirmation.totals);
  const href = new URL(journalMailto('client@example.test', confirmation.subject, confirmation.body));
  assert.equal(href.searchParams.get('subject'), confirmation.subject);
  assert.equal(href.searchParams.get('body'), confirmation.body);
});

test('UI exposes the VAT email action and uses active working rows without deleting historical records', () => {
  const view = readFileSync(new URL('../src/components/CompanyGlJournalView.tsx', import.meta.url), 'utf8');
  for (const label of ['Object', 'Department', 'Employee', 'Vehicle', 'Created by']) assert.ok(view.includes(`label: "${label}"`));
  assert.match(view, />New journal<\/PageActionButton>/); assert.match(view, /<RowDeleteButton deactivationIcon="trash" linked inactive=/);
  assert.match(view, /data-record-inactive=/); assert.match(view, /Print GL journal/);
  assert.match(view, /data-record-inactive=\{group\.rows\.every\(entry => entry\.inactive\)/);
  assert.match(view, /filteredRows\.filter\(row => !row\.inactive\)/);
  const ledger = readFileSync(new URL('../src/components/GeneralLedgerView.tsx', import.meta.url), 'utf8');
  assert.equal((ledger.match(/deactivationIcon="trash"/g) || []).length, 3);
  assert.match(view, /journalWorkingRows\(candidates\)/);
  assert.match(view, />Send VAT reconciliation<\/PageActionButton>/);
  assert.match(view, /<VatReconciliationCompanyDialog company=\{company\}/);
  assert.doesNotMatch(view, /will remain visible as inactive/);
  const print = readFileSync(new URL('../src/components/GlJournalPrintView.tsx', import.meta.url), 'utf8');
  assert.match(print, /rows\.map\(row/); assert.doesNotMatch(print, /\.slice\(/);
  const email = readFileSync(new URL('../src/components/GlJournalClosingDialog.tsx', import.meta.url), 'utf8');
  assert.match(email, /window\.location\.href = href/); assert.doesNotMatch(email, /appendOrganizationEmailHistory|fetch\(/);
  assert.match(email, /VAT email template/);
  assert.doesNotMatch(email, /Email purpose|Input VAT account|Output VAT account|Additional message \(optional\)/);
  assert.match(email, /total\.recoverableMinor \|\| total\.payableMinor/);
  assert.match(email, /useState\(initialRecipient\)/);
  const emailHandler = email.split('const prepareEmail = () => {')[1].split('return createPortal')[0];
  assert.doesNotMatch(emailHandler, /saveClosingPeriod|setItem|reconciled: true/);
});

test('VAT estimate keeps currencies separate and handles corrections, payable and surplus', () => {
  const period = { from: '2026-09-01', to: '2026-09-30' };
  const base = { ...rows[0], operationDate: '2026-09-15', posted: true, balanced: true };
  const input = [
    { ...base, account: '2441', debit: 100, credit: 0 },
    { ...base, account: '2441', debit: 0, credit: 10 },
    { ...base, account: '4484', debit: 0, credit: 150 },
    { ...base, account: '4484', debit: 5, credit: 0 },
    { ...base, account: '2441', debit: 30, credit: 0, document: { ...base.document, currency: 'USD' } },
    { ...base, account: '4484', debit: 0, credit: 900, inactive: true },
    { ...base, account: '4484', debit: 0, credit: 900, posted: false },
  ];
  const result = journalVatCalculation(input, period, ['2441', '4484']);
  assert.equal(result.error, '');
  assert.deepEqual(result.amounts.find(item => item.currency === 'EUR'), { currency: 'EUR', inputMinor: 9000, outputMinor: 14500, payableMinor: 5500, recoverableMinor: 0 });
  assert.equal(result.amounts.find(item => item.currency === 'USD').recoverableMinor, 3000);
  assert.ok(journalVatCalculation(input, period, ['2441', '2441']).error);
  assert.ok(journalVatCalculation([{ ...base, account: '2441', debit: 10, credit: 10 }], period, ['2441', '4484']).error);
  assert.deepEqual(journalVatCalculation([], period, ['2441', '4484']).amounts, []);
});

test('VAT templates render company-specific values once and validate custom placeholders', () => {
  const data = { company: 'Company B', recipient: 'Contact B', periodFrom: '2026-09-01', periodTo: '2026-09-30', vatSummary: 'EUR · Estimated VAT payable 55.00', message: 'Please confirm.' };
  for (const template of VAT_EMAIL_TEMPLATES) {
    assert.equal(validateVatTemplate(template), '');
    const body = renderVatTemplate(template.body, data);
    assert.match(body, /Company B/); assert.match(body, /55.00/); assert.doesNotMatch(body, /\{\{/);
  }
  assert.ok(validateVatTemplate({ name: '', subject: 'Test', body: 'Test' }));
  assert.ok(validateVatTemplate({ name: 'Test', subject: '{{unknown}}', body: 'Test' }));
  assert.equal(renderVatTemplate('{{company}}', { ...data, company: '{{recipient}}' }), '{{recipient}}');
});

test('company selector uses accessible saved companies and never mixes another company with current test rows', () => {
  const wrapper = readFileSync(new URL('../src/components/VatReconciliationCompanyDialog.tsx', import.meta.url), 'utf8');
  assert.match(wrapper, /from\('companies'\)/); assert.match(wrapper, /canAccessAssignedOrganization\(item, session\)/);
  assert.match(wrapper, /initialRecipient=\{data.company.email\}/);
  assert.match(wrapper, /key=\{data.company.id\}/); assert.match(wrapper, /data.company.id !== selectedId/);
  const view = readFileSync(new URL('../src/components/CompanyGlJournalView.tsx', import.meta.url), 'utf8');
  assert.match(view, /eq\('company_id', selected.id\)/);
  assert.match(view, /loadJournalDrafts\(window.localStorage, selected.id, 'company'\)/);
});
