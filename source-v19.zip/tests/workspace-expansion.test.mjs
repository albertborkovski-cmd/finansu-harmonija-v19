import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const compiled = ts.transpileModule(read('src/hooks/useWorkspaceExpansion.ts'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext },
}).outputText.replace(/import \{ useLayoutEffect \} from ['"]react['"];?/, 'const useLayoutEffect = effect => { globalThis.workspaceTestEffect = effect; };');
const { default: useWorkspaceExpansion } = await import(`data:text/javascript;base64,${Buffer.from(compiled).toString('base64')}`);

function element(parentElement = null, dialog = null) {
  const attributes = new Map();
  return {
    parentElement, scrollTop: 20, scrollLeft: 10, attributes,
    closest: () => dialog,
    setAttribute: (key, value) => attributes.set(key, value),
    removeAttribute: key => attributes.delete(key),
    getClientRects: () => [{}],
  };
}

function fixture() {
  const originals = Object.fromEntries(['document', 'window', 'MutationObserver', 'getComputedStyle'].map(key => [key, globalThis[key]]));
  const root = element(); const path = element(root); const viewport = element(path);
  const heading = element(root); const breadcrumb = element(root); const overview = element(root);
  const modal = element(root); const modalHeading = element(modal, modal); const modalViewport = element(modal, modal);
  let currentViewport = viewport; let observer; let onKey; let popups = []; let resizeCount = 0; let exitCount = 0;
  root.querySelectorAll = selector => selector === '[data-system-table-viewport]' ? [modalViewport, currentViewport]
    : selector === '[data-system-page-header]' ? [heading, modalHeading] : [breadcrumb, overview];
  globalThis.document = {
    body: { style: { overflow: 'auto' } }, querySelectorAll: () => popups,
    addEventListener: (name, handler) => { if (name === 'keydown') onKey = handler; },
    removeEventListener: (name, handler) => { if (name === 'keydown' && onKey === handler) onKey = undefined; },
  };
  globalThis.window = { dispatchEvent: () => { resizeCount++; } };
  globalThis.getComputedStyle = () => ({ visibility: 'visible' });
  globalThis.MutationObserver = class {
    constructor(callback) { this.callback = callback; observer = this; }
    observe() { this.connected = true; }
    disconnect() { this.connected = false; }
  };
  useWorkspaceExpansion(true, root, value => { if (value === false) exitCount++; });
  const cleanup = globalThis.workspaceTestEffect();
  return {
    root, path, viewport, heading, breadcrumb, overview, modalHeading, modalViewport,
    cleanup, observer: () => observer, resizeCount: () => resizeCount, exitCount: () => exitCount,
    key: (event = {}) => onKey?.({ key: 'Escape', defaultPrevented: false, ...event }),
    setPopups: value => { popups = value; },
    replaceViewport: value => { currentViewport = value; observer.callback(); },
    restore: () => { cleanup(); for (const [key, value] of Object.entries(originals)) { if (value === undefined) delete globalThis[key]; else globalThis[key] = value; } delete globalThis.workspaceTestEffect; },
  };
}

test('fullscreen marks the original list and compacts only its heading and overview', () => {
  const f = fixture();
  try {
    assert.equal(f.root.attributes.get('data-table-workspace-expanded'), 'true');
    assert.equal(f.viewport.attributes.get('data-expanded-table-viewport'), 'true');
    assert.equal(f.path.attributes.get('data-expanded-table-path'), 'true');
    assert.equal(f.heading.attributes.get('data-expanded-workspace-heading'), 'true');
    assert.equal(f.breadcrumb.attributes.get('data-expanded-workspace-hidden'), 'true');
    assert.equal(f.overview.attributes.get('data-expanded-workspace-hidden'), 'true');
    assert.equal(f.modalHeading.attributes.size, 0);
    assert.equal(f.modalViewport.attributes.size, 0);
    assert.equal(document.body.style.overflow, 'hidden');
    assert.equal(f.resizeCount(), 1);
  } finally { f.restore(); }
});

test('Escape respects dialogs/popups but is not blocked by record group expansion', () => {
  const f = fixture();
  try {
    f.setPopups([element()]); f.key(); assert.equal(f.exitCount(), 0);
    f.setPopups([]); f.key({ defaultPrevented: true }); assert.equal(f.exitCount(), 0);
    f.key({ key: 'Enter' }); assert.equal(f.exitCount(), 0);
    f.key(); assert.equal(f.exitCount(), 1);
    const source = read('src/hooks/useWorkspaceExpansion.ts');
    assert.match(source, /\[aria-haspopup\]\[aria-expanded="true"\]/);
    assert.doesNotMatch(source, /, \[aria-expanded="true"\]/);
  } finally { f.restore(); }
});

test('switching stages applies fullscreen sizing to the replacement viewport', () => {
  const f = fixture();
  try {
    const replacement = element(f.root);
    f.replaceViewport(replacement);
    assert.equal(replacement.attributes.get('data-expanded-table-viewport'), 'true');
    assert.equal(f.viewport.attributes.has('data-expanded-table-viewport'), false);
    assert.equal(f.path.attributes.has('data-expanded-table-path'), false);
    assert.equal(f.root.attributes.get('data-table-workspace-expanded'), 'true');
  } finally { f.restore(); }
});

test('exit restores scrolling and removes temporary attributes/listeners/observer', () => {
  const f = fixture();
  try {
    f.root.scrollTop = 0; f.path.scrollTop = 0; f.viewport.scrollTop = 120;
    f.cleanup();
    for (const node of [f.root, f.path, f.viewport, f.heading, f.breadcrumb, f.overview]) assert.equal(node.attributes.size, 0);
    assert.equal(document.body.style.overflow, 'auto');
    assert.equal(f.root.scrollTop, 20); assert.equal(f.path.scrollTop, 20);
    assert.equal(f.viewport.scrollTop, 120);
    assert.equal(f.observer().connected, false);
    assert.equal(f.resizeCount(), 2);
    f.key(); assert.equal(f.exitCount(), 0);
  } finally { f.restore(); }
});

test('Reconciliation and all shared tables use one lifecycle, button and fullscreen sizing', () => {
  for (const path of ['src/components/TableWorkspaceExpand.tsx', 'src/components/CompanyReconciliationView.tsx']) {
    assert.match(read(path), /useWorkspaceExpansion\(/);
  }
  for (const path of ['src/components/TableWorkspaceExpand.tsx', 'src/components/ReconciliationTable.tsx']) {
    assert.match(read(path), /<WorkspaceExpandButton/);
  }
  const css = read('src/index.css');
  const workspace = css.slice(css.indexOf('[data-table-workspace-expanded] {'), css.indexOf('[data-table-workspace-expanded] [data-expanded-workspace-heading]'));
  for (const declaration of ['inset: 0', 'height: 100dvh', 'padding: 16px', 'gap: 12px', 'z-index: 45']) assert.ok(workspace.includes(declaration));
  assert.doesNotMatch(css, /data-gl-journal-expanded-create|data-gl-journal-heading/);
  assert.equal((read('src/components/CompanyGlJournalView.tsx').match(/>New journal<\/PageActionButton>/g) || []).length, 1);
  assert.match(read('src/components/TableWorkspaceExpand.tsx'), /closest\('\[data-reconciliation-workspace\]'\)/);
});
