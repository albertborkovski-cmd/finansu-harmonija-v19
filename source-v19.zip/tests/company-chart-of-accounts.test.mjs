import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import test from 'node:test';
import ts from 'typescript';

const source = readFileSync(new URL('../src/components/GeneralLedgerView.tsx', import.meta.url), 'utf8');
const detail = readFileSync(new URL('../src/components/CompanyDetail.tsx', import.meta.url), 'utf8');
const names = ['applyCompanyLedgerCustomization', 'buildCompanyLedgerCustomization', 'buildLedgerAccountTree', 'loadCompanyGeneralLedgerAccounts', 'loadCompanyGeneralLedgerAccountHierarchy', 'addCompanyGeneralLedgerAccount', 'companyCostCenterOptions', 'isAccountUsageColumn', 'accountColumnValue'];
const ast = ts.createSourceFile('ledger.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
const functions = ast.statements.filter(node => ts.isFunctionDeclaration(node) && names.includes(node.name?.text)).map(node => node.getText(ast)).join('\n');
const constants = ast.statements.filter(node => ts.isVariableStatement(node) && node.declarationList.declarations.some(declaration => ['ACCOUNT_COLUMNS', 'COMPANY_ACCOUNT_COLUMNS'].includes(declaration.name.getText(ast)))).map(node => node.getText(ast)).join('\n');
const code = ts.transpileModule(`${constants}\n${functions}\nexport { ${names.join(', ')}, ACCOUNT_COLUMNS, COMPANY_ACCOUNT_COLUMNS };`, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
const plain = value => JSON.parse(JSON.stringify(value));
const account = (code, parentCode) => ({ id: `a-${code}`, code, name: `Account ${code}`, type: 'Asset', active: true, ...(parentCode ? { parentCode } : {}) });

function fixture() {
  const templates = [
    { id: 'standard', name: 'Standard', active: true, accounts: [account('1'), account('11', '1'), account('111', '11'), account('2')] },
    { id: 'custom', name: 'Custom', active: true, accounts: [account('9')] },
  ];
  templates.forEach(template => { template.accounts.forEach(Object.freeze); Object.freeze(template.accounts); Object.freeze(template); });
  Object.freeze(templates);
  const values = new Map([['finansu-harmonija:v7:general-ledger-templates', JSON.stringify(templates)]]);
  const localStorage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) };
  const events = [];
  const module = { exports: {} };
  let nextId = 0;
  runInNewContext(code, { module, exports: module.exports, loadGeneralLedgerTemplates: () => templates, window: { localStorage, dispatchEvent: event => events.push(event) }, crypto: { randomUUID: () => `test-${++nextId}` }, CustomEvent: class { constructor(type, options) { this.type = type; this.detail = options?.detail; } } });
  return { ...module.exports, templates, localStorage, events };
}

test('GL journal opens the assigned company chart using the existing company-scoped editor', () => {
  assert.match(detail, /id: 'chart-of-accounts', label: 'Chart of accounts'/);
  assert.match(detail, /activeGlJournalMenu === 'chart-of-accounts'\s*\? <GeneralLedgerView key=\{`\$\{currentCompany.id\}:\$\{currentCompany.general_ledger \?\? ''\}`\} companyId=\{currentCompany.id\} companyName=\{currentCompany.name\} assignedTemplateName=\{currentCompany.general_ledger \?\? ''\} companyContext="journal"/);
  assert.match(source, /items=\{\['GL journal', 'Chart of accounts'\]\}/);
  assert.match(source, /if \(companyId\) return;\s*window.localStorage.setItem\(STORAGE_KEY/);
  assert.match(source, /if \(companyId && baseSelectedTemplate\) \{\s*setCompanyLedgerCustomizations/);
  assert.match(source, /No general ledger template assigned/);
});

test('company chart shares the template title, back button, breadcrumbs and toolbar layout with Settings', () => {
  assert.match(source, /title=\{companyContext === 'journal' \|\| onBack \? selectedTemplate.name : companyName \?\? selectedTemplate.name\}/);
  assert.match(detail, /companyContext="journal" onBack=\{\(\) => setActiveGlJournalMenu\('journal'\)\}/);
  assert.match(source, /companyContext === 'journal' \? 'Back to GL journal' : 'Back to Accounting setup'/);
  assert.match(source, /<nav aria-label="Breadcrumb" data-system-breadcrumb className="flex items-center gap-2 font-montserrat text-\[12px\] font-medium text-\[#7288A3\]">/);
  assert.match(source, /companyName && !onBack && companyContext !== 'journal'/);
  const component = ast.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'GeneralLedgerView');
  const selectedView = component.body.statements.find(node => ts.isIfStatement(node) && node.expression.getText(ast) === 'selectedTemplate').getText(ast);
  assert.equal((selectedView.match(/ref=\{templateTableScrollRef\}/g) || []).length, 1);
  assert.match(selectedView, /<PageActionButton[\s\S]*Import structure[\s\S]*Create new/);
});

test('editing, adding, deactivating and removing company accounts leaves the original template and other companies unchanged', () => {
  const f = fixture();
  const sharedBefore = f.localStorage.getItem('finansu-harmonija:v7:general-ledger-templates');
  const base = f.templates[0].accounts;
  const edited = [
    { ...base[0], name: 'Company A assets' },
    { ...base[1], active: false },
    base[3],
    account('2999', '2'),
  ];
  f.localStorage.setItem('finansu-harmonija:v12:company-general-ledger:company-a', JSON.stringify({ standard: f.buildCompanyLedgerCustomization(base, edited) }));
  const customization = JSON.parse(f.localStorage.getItem('finansu-harmonija:v12:company-general-ledger:company-a')).standard;
  assert.deepEqual(plain(f.applyCompanyLedgerCustomization(base, customization)), edited);
  assert.deepEqual(plain(f.loadCompanyGeneralLedgerAccounts('company-b', 'Standard')), plain(base));
  assert.deepEqual(plain(f.loadCompanyGeneralLedgerAccounts('company-a', 'Standard')).map(row => row.code), ['1', '2', '2999']);
  assert.equal(f.loadCompanyGeneralLedgerAccounts('company-a', 'Standard')[0].name, 'Company A assets');
  assert.equal(f.localStorage.getItem('finansu-harmonija:v7:general-ledger-templates'), sharedBefore);
  assert.equal(base[0].name, 'Account 1');
  assert.equal(base[1].active, true);
});

test('adding an account through the shared company API uses the assigned template and remains visible after reload', () => {
  const f = fixture();
  const before = f.localStorage.getItem('finansu-harmonija:v7:general-ledger-templates');
  assert.equal(f.addCompanyGeneralLedgerAccount('company-a', 'Custom', { code: '91', name: 'Company-only account', parentCode: '9' }), true);
  assert.deepEqual(plain(f.loadCompanyGeneralLedgerAccountHierarchy('company-a', 'Custom')).map(row => [row.code, row.depth]), [['9', 0], ['91', 1]]);
  assert.deepEqual(plain(f.loadCompanyGeneralLedgerAccountHierarchy('company-b', 'Custom')).map(row => row.code), ['9']);
  assert.equal(f.loadCompanyGeneralLedgerAccounts('company-a', 'Standard').length, 4);
  assert.equal(f.localStorage.getItem('finansu-harmonija:v7:general-ledger-templates'), before);
  assert.equal(f.events.some(event => event.type === 'company-general-ledger-updated' && event.detail.companyId === 'company-a'), true);
});

test('company account cost center and independent usage flags persist without changing shared templates or other companies', () => {
  const f = fixture();
  const before = f.localStorage.getItem('finansu-harmonija:v7:general-ledger-templates');
  const base = f.templates[0].accounts;
  const edited = base.map(row => row.code === '111' ? {
    ...row, costCenter: 'CC-10', inventory: true, calculateExchangeDifferences: false, expenseReports: true,
    accountingBank: 'Test bank', saftCode: 'LT-111', saftName: 'Development costs',
  } : row);
  f.localStorage.setItem('finansu-harmonija:v12:company-general-ledger:company-a', JSON.stringify({ standard: f.buildCompanyLedgerCustomization(base, edited) }));
  const loaded = plain(f.loadCompanyGeneralLedgerAccountHierarchy('company-a', 'Standard')).find(row => row.code === '111');
  assert.equal(loaded.costCenter, 'CC-10');
  assert.equal(loaded.inventory, true);
  assert.equal(loaded.calculateExchangeDifferences, false);
  assert.equal(loaded.expenseReports, true);
  assert.equal(loaded.accountingBank, 'Test bank');
  assert.equal(loaded.saftCode, 'LT-111');
  assert.equal(loaded.saftName, 'Development costs');
  assert.equal(f.loadCompanyGeneralLedgerAccounts('company-b', 'Standard').find(row => row.code === '111').costCenter, undefined);
  assert.equal(f.localStorage.getItem('finansu-harmonija:v7:general-ledger-templates'), before);
  const cleared = edited.map(row => row.code === '111' ? { ...row, costCenter: undefined, inventory: false, expenseReports: false } : row);
  f.localStorage.setItem('finansu-harmonija:v12:company-general-ledger:company-a', JSON.stringify({ standard: f.buildCompanyLedgerCustomization(base, cleared) }));
  const reloaded = f.loadCompanyGeneralLedgerAccounts('company-a', 'Standard').find(row => row.code === '111');
  assert.equal(reloaded.costCenter, undefined);
  assert.equal(reloaded.inventory, false);
  assert.equal(reloaded.expenseReports, false);
});

test('cost center options keep configured names, merge used codes, deduplicate and support legacy company settings', () => {
  const f = fixture();
  assert.deepEqual(plain(f.companyCostCenterOptions(JSON.stringify({ items: [{ code: 'CC-10', name: 'Administration' }, { code: 'CC-2', name: 'Sales' }, null] }), ['CC-10', 'cc-2', ' CC-3 ', ''])), [
    { value: 'CC-2', label: 'CC-2 — Sales' },
    { value: 'CC-3', label: 'CC-3' },
    { value: 'CC-10', label: 'CC-10 — Administration' },
  ]);
  assert.deepEqual(plain(f.companyCostCenterOptions(' SALES, OFFICE, SALES ', [])), [{ value: 'OFFICE', label: 'OFFICE' }, { value: 'SALES', label: 'SALES' }]);
  assert.deepEqual(plain(f.companyCostCenterOptions('{invalid', ['EXISTING'])), [{ value: 'EXISTING', label: 'EXISTING' }]);
  assert.deepEqual(plain(f.companyCostCenterOptions(undefined, [])), []);
});

test('account editor uses company-scoped cost center sources and keeps usage flags out of shared template editing', () => {
  assert.match(source, /<AccountEditor[\s\S]*?companyId=\{companyId\}/);
  assert.match(source, /from\('companies'\)\.select\('cost_centers'\)\.eq\('id', companyId\)/);
  assert.match(source, /from\('lookup_values'\)\.select\('\*'\)\.eq\('type', `cost_center::company::\$\{companyId\}`\)/);
  assert.match(source, /from\('documents'\)\.select\('cost_center'\)\.eq\('company_id', companyId\)/);
  assert.match(source, /\{companyId && <>[\s\S]*?<SearchableSelect[\s\S]*?ariaLabel="Cost center"[\s\S]*?Account usage/);
  assert.match(source, /\['inventory', 'Inventory'\]/);
  assert.match(source, /\['calculateExchangeDifferences', 'Calculate exchange rate differences'\]/);
  assert.match(source, /\['expenseReports', 'Expense reports'\]/);
  assert.match(source, /\.\.\.mergedAccounts\[existingIndex\],\s*\.\.\.importedAccount/);
  assert.match(source, /active: mergedAccounts\[existingIndex\]\.active && importedAccount\.active/);
});

test('company chart exposes requested English columns without changing the global template columns', () => {
  const f = fixture();
  assert.deepEqual(plain(f.COMPANY_ACCOUNT_COLUMNS).map(column => column.label), [
    'GL account', 'Name', 'Account type', 'Parent account code', 'Inventory',
    'Calculate exchange rate differences', 'Expense reports', 'Cost center',
    'Accounting bank', 'ID', 'SAF-T code', 'SAF-T code name', 'Active',
  ]);
  assert.equal(f.COMPANY_ACCOUNT_COLUMNS.every(column => column.visible), true);
  assert.equal(new Set(f.COMPANY_ACCOUNT_COLUMNS.map(column => column.key)).size, 13);
  assert.deepEqual(plain(f.ACCOUNT_COLUMNS).map(column => column.key), ['code', 'name', 'type', 'active']);
  assert.match(source, /defaultAccountColumns = companyId \? COMPANY_ACCOUNT_COLUMNS : ACCOUNT_COLUMNS/);
  assert.match(source, /defaultColumns=\{defaultAccountColumns\}/);
  assert.match(source, /columns=\{defaultAccountColumns\.map/);
  assert.match(source, /startAccountResize\(accountColumns\.findIndex\(item => item.key === column.key\), event\)/);
});

test('table and filters share readable values, including false flags and empty legacy fields', () => {
  const f = fixture();
  const row = { ...account('111', '11'), inventory: true, expenseReports: false, costCenter: ' CC-10 ', saftCode: 'LT-111', saftName: 'Development costs' };
  assert.equal(f.accountColumnValue(row, 'parentCode'), '11');
  assert.equal(f.accountColumnValue(row, 'inventory'), 'Yes');
  assert.equal(f.accountColumnValue(row, 'expenseReports'), 'No');
  assert.equal(f.accountColumnValue(row, 'calculateExchangeDifferences'), 'No');
  assert.equal(f.accountColumnValue(row, 'costCenter'), 'CC-10');
  assert.equal(f.accountColumnValue(row, 'accountingBank'), '—');
  assert.equal(f.accountColumnValue(row, 'id'), 'a-111');
  assert.equal(f.accountColumnValue(row, 'saftCode'), 'LT-111');
  assert.equal(f.accountColumnValue(row, 'saftName'), 'Development costs');
  assert.equal(f.accountColumnValue({ ...row, active: false }, 'active'), 'No');
  assert.match(source, /selected.includes\(accountColumnValue\(account, key as AccountColumnKey\)\)/);
  assert.match(source, /aria-checked=\{Boolean\(account\[column.key\]\)\}\s*aria-readonly="true"/);
});

test('tree expands and collapses entire branches without returning hidden descendants as orphan rows', () => {
  const f = fixture();
  const accounts = f.templates[0].accounts;
  const codes = expanded => plain(f.buildLedgerAccountTree(accounts, new Set(expanded))).map(row => row.code);
  assert.deepEqual(codes(['1', '11']), ['1', '11', '111', '2']);
  assert.deepEqual(codes(['1']), ['1', '11', '2']);
  assert.deepEqual(codes(['11']), ['1', '2']);
  assert.deepEqual(codes([]), ['1', '2']);
  assert.deepEqual(plain(f.buildLedgerAccountTree([accounts[2]], new Set())).map(row => row.code), ['111']);
});

test('tree retains filtered/orphan accounts and safely handles legacy cycles', () => {
  const f = fixture();
  const rows = [account('1', '11'), account('11', '1'), account('2', 'missing')];
  const result = plain(f.buildLedgerAccountTree(rows, new Set(['1', '11'])));
  assert.deepEqual(result.map(row => row.code), ['2', '1', '11']);
  assert.equal(new Set(result.map(row => row.id)).size, result.length);
});
