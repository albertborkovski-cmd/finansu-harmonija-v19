import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import ts from 'typescript';

async function load(path) {
  const code = ts.transpileModule(readFileSync(new URL(path, import.meta.url), 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
  return import(`data:text/javascript;base64,${Buffer.from(code).toString('base64')}`);
}
const { calculateRevaluation, journalRevaluationRates, revaluationDraft, revaluationRate, revaluationResultRows, revaluationSelectableAccounts, SAMPLE_REVALUATION_RATES } = await load('../src/lib/glJournalRevaluation.ts');
const { createSampleJournalRows } = await load('../src/lib/glJournal.ts');
const { journalDraftError, saveJournalDraft, loadJournalDrafts, journalDraftRows } = await load('../src/lib/glJournalDrafts.ts');
const accounts = [
  { code: '2410', name: 'Receivables', type: 'Receivable' }, { code: '4430', name: 'Payables', type: 'Payable' },
  { code: '4431', name: 'Other payables to suppliers', type: 'Payable' },
  { code: '2710', name: 'Bank', type: 'Bank & Cash' }, { code: '5800', name: 'FX gain', type: 'Income' }, { code: '6800', name: 'FX loss', type: 'Expense' },
];
const settings = { date: '2026-10-19', baseCurrency: 'EUR', accountCodes: ['2410', '4430', '2710'], gainAccount: '5800', lossAccount: '6800' };
const rates = [{ id: 'usd', code: 'USD', date: '2026-10-19', quantity: 1, rate: 1.25 }];
function row(id, account, debit, credit, baseDebit, baseCredit, extra = {}) {
  return { id, account, accountName: account, documentNumber: id, internalNumber: id, operationDate: '2026-10-01', counterparty: 'Client A',
    debit, credit, baseDebit, baseCredit, baseCurrency: 'EUR', accountActive: true, posted: true, postingStatus: 'Posted', balanced: true,
    documentType: 'Invoice', documentSubtype: '', costCenter: '', total: Math.max(debit, credit), document: { id, number: id, currency: 'USD', status: 'Approved', documentType: 'Invoice', source: 'Test' }, ...extra };
}

test('asset losses and liability gains generate opposite, balanced correspondences', () => {
  const report = calculateRevaluation([row('sale', '2410', 1100, 0, 1000, 0), row('purchase', '4430', 0, 1100, 0, 1000)], accounts, rates, settings);
  assert.deepEqual(report.issues, []);
  assert.deepEqual(report.lines.map(line => [line.account, line.carryingMinor, line.revaluedMinor, line.differenceMinor, line.debitAccount, line.creditAccount]), [
    ['2410', 100000, 88000, -12000, '6800', '2410'], ['4430', -100000, -88000, 12000, '4430', '5800'],
  ]);
  const draft = revaluationDraft(report, 'BZ-2026-0001');
  assert.equal(draft.currency, 'EUR');
  assert.equal(journalDraftError(draft, accounts, []), '');
  assert.equal(draft.lines.reduce((sum, line) => sum + Number(line.debit) - Number(line.credit), 0), 0);
});

test('asset gains and liability losses use the correct side', () => {
  const report = calculateRevaluation([row('sale', '2410', 1100, 0, 1000, 0), row('purchase', '4430', 0, 1100, 0, 1000)], accounts, [{ ...rates[0], rate: 1 }], settings);
  assert.deepEqual(report.lines.map(line => [line.debitAccount, line.creditAccount, line.amountMinor]), [['2410', '5800', 10000], ['6800', '4430', 10000]]);
});

test('uses cumulative balances and posted historical base amounts, never a period turnover', () => {
  const report = calculateRevaluation([
    row('old-sale', '2410', 1100, 0, 1000, 0, { operationDate: '2026-01-01' }),
    row('part-paid', '2410', 0, 550, 0, 500),
    row('prior-revaluation', '2410', 0, 0, 50, 0),
    row('future', '2410', 5000, 0, 4500, 0, { operationDate: '2026-10-20' }),
    row('draft', '2410', 5000, 0, 4500, 0, { posted: false }),
    row('inactive', '2410', 5000, 0, 4500, 0, { inactive: true }),
    row('eur', '2410', 5000, 0, 5000, 0, { document: { id: 'eur', currency: 'EUR' } }),
  ], accounts, rates, settings);
  assert.equal(report.lines.length, 1);
  assert.equal(report.lines[0].foreignMinor, 55000);
  assert.equal(report.lines[0].carryingMinor, 55000);
  assert.equal(report.lines[0].revaluedMinor, 44000);
  assert.equal(report.lines[0].differenceMinor, -11000);
});

test('counterparties are separate, bank balances combine movements across counterparties', () => {
  const report = calculateRevaluation([
    row('a', '2410', 1100, 0, 1000, 0), row('b', '2410', 0, 1100, 0, 1000, { counterparty: 'Client B' }),
    row('bank-in', '2710', 2000, 0, 1800, 0), row('bank-out', '2710', 0, 1000, 0, 900, { counterparty: 'Client B' }),
  ], accounts, rates, settings);
  assert.equal(report.lines.filter(line => line.account === '2410').length, 2);
  assert.equal(report.lines.filter(line => line.account === '2710').length, 1);
  assert.equal(report.lines.find(line => line.account === '2710').foreignMinor, 100000);
});

test('rate direction, quantity, non-EUR cross rates, weekends and future dates', () => {
  const input = [{ ...rates[0], date: '2026-10-16', quantity: 100, rate: 125 }, { id: 'gbp', code: 'GBP', date: '2026-10-16', quantity: 1, rate: 0.8 }, { ...rates[0], id: 'future', date: '2026-10-20', rate: 50 }];
  assert.deepEqual(revaluationRate(input, 'USD', 'EUR', '2026-10-18'), { value: 0.8, date: '2026-10-16' });
  assert.equal(revaluationRate(input, 'USD', 'GBP', '2026-10-18').value, 0.64);
  assert.throws(() => revaluationRate(input, 'USD', 'EUR', '2026-10-15'), /no exchange rate/);
});

test('Settings rates override demo rates; real-company mode never uses fictional rates', () => {
  const empty = { getItem: () => null };
  assert.deepEqual(journalRevaluationRates(empty, false), []);
  assert.deepEqual(journalRevaluationRates(empty, true), SAMPLE_REVALUATION_RATES);
  const configured = { getItem: () => JSON.stringify(rates) };
  assert.deepEqual(journalRevaluationRates(configured, true), rates);
  assert.throws(() => revaluationRate(journalRevaluationRates(configured, true), 'USD', 'EUR', '2026-10-01'), /no exchange rate/);
});

test('missing or inconsistent data prevents a partial group calculation and journal creation', () => {
  const bad = calculateRevaluation([row('ok', '2410', 100, 0, 90, 0), row('missing', '2410', 100, 0, undefined, undefined)], accounts, rates, settings);
  assert.equal(bad.lines.length, 0);
  assert.match(bad.issues.join(' '), /booked EUR amounts are missing/);
  assert.throws(() => revaluationDraft(bad, 'BZ'), /Resolve the missing data/);
  const missing = calculateRevaluation([row('missing-rate', '2410', 100, 0, 90, 0)], accounts, [], settings);
  assert.match(missing.issues.join(' '), /no exchange rate/);
  const conflicting = calculateRevaluation([row('conflict', '2410', 100, 0, 90, 0)], accounts, [...rates, { ...rates[0], id: 'conflict', rate: 2 }], settings);
  assert.match(conflicting.issues.join(' '), /conflicting exchange rates/);
  assert.throws(() => calculateRevaluation([], accounts, rates, { ...settings, date: '2026-02-30' }), /valid revaluation date/);
  assert.throws(() => calculateRevaluation([], accounts, rates, { ...settings, accountCodes: ['5800'] }), /Receivable/);
});

test('settled foreign balances retain residual base adjustment and zero differences create no posting', () => {
  const report = calculateRevaluation([row('sale', '2410', 1100, 0, 1000, 0), row('settled', '2410', 0, 1100, 0, 990)], accounts, rates, settings);
  assert.equal(report.lines[0].foreignMinor, 0);
  assert.equal(report.lines[0].differenceMinor, -1000);
  const zero = calculateRevaluation([row('no-change', '2410', 1250, 0, 1000, 0)], accounts, rates, settings);
  assert.equal(zero.lines[0].amountMinor, 0);
  assert.throws(() => revaluationDraft(zero, 'BZ'), /no exchange differences/);
});

test('test data gives balanced revaluation entries and saved report is company-scoped and unposted', () => {
  const report = calculateRevaluation(createSampleJournalRows('alice'), accounts, SAMPLE_REVALUATION_RATES, settings);
  assert.ok(report.lines.length > 5);
  assert.deepEqual(report.issues, []);
  assert.equal(calculateRevaluation(createSampleJournalRows('alice'), accounts, SAMPLE_REVALUATION_RATES, report).fingerprint, report.fingerprint);
  const data = new Map(); const storage = { getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, value) };
  const draft = revaluationDraft(report, 'BZ-2026-0001');
  const saved = saveJournalDraft(storage, { companyId: 'alice', mode: 'test', id: 'fx-1', createdAt: '2026-10-19T09:00:00Z', createdBy: 'Accountant', revaluation: report }, draft, accounts, []);
  assert.equal(saved.revaluation.fingerprint, report.fingerprint);
  assert.equal(loadJournalDrafts(storage, 'bob', 'test').length, 0);
  assert.equal(loadJournalDrafts(storage, 'alice', 'company').length, 0);
  const journal = journalDraftRows(loadJournalDrafts(storage, 'alice', 'test'), new Set(accounts.map(account => account.code)));
  assert.ok(journal.every(line => !line.posted && line.document.currency === 'EUR' && line.balanced));
  assert.throws(() => saveJournalDraft(storage, { companyId: 'alice', mode: 'test', id: 'fx-1', createdAt: '', createdBy: '' }, draft, accounts, []), /already exists|already saved/);
});

test('revaluation choices come only from journal rows, with one option per account', () => {
  assert.deepEqual(revaluationSelectableAccounts(accounts, []), []);
  const first = row('first', '4431', 0, 100, 0, 90);
  assert.deepEqual(revaluationSelectableAccounts(accounts, [first]), [accounts.find(account => account.code === '4431')]);
  const repeated = row('repeated', '4431', 0, 200, 0, 180);
  assert.equal(revaluationSelectableAccounts(accounts, [first, repeated]).length, 1);
  const second = row('second', '2710', 100, 0, 90, 0);
  assert.deepEqual(revaluationSelectableAccounts(accounts, [first, repeated, second]).map(account => account.code), ['2710', '4431']);
  // Neither other-company chart options nor a previous selection populate this journal.
  assert.deepEqual(revaluationSelectableAccounts(accounts, [second]).map(account => account.code), ['2710']);
});

test('journal choices retain document account metadata and are not a static monetary-account list', () => {
  const used = [row('expense', '6800', 100, 0, 90, 0), row('custom', '4499', 0, 100, 0, 90, { accountName: 'Custom supplier account' }), row('empty', '—', 0, 0, 0, 0)];
  assert.deepEqual(revaluationSelectableAccounts(accounts, used), [
    { code: '4499', name: 'Custom supplier account' }, accounts.find(account => account.code === '6800'),
  ]);
  // Account-type validation remains in the calculation, not in the journal-derived list.
  assert.throws(() => calculateRevaluation(used, accounts, rates, { ...settings, accountCodes: ['6800'] }), /Receivable/);
});

test('demo revaluation offers used supplier accounts without relabelling bank postings', () => {
  const sample = createSampleJournalRows('alice');
  const choices = revaluationSelectableAccounts(accounts, sample);
  assert.deepEqual(new Set(choices.map(account => account.code)), new Set(sample.map(row => row.account)));
  assert.ok(choices.some(account => account.code === '4431'));
  assert.ok(sample.some(row => row.account === '2710' && row.accountName === 'Bank account'));
  assert.ok(sample.some(row => row.account === '4431' && row.accountName === 'Other payables to suppliers' && row.credit > 0 && row.document.currency === 'USD'));
  const report = calculateRevaluation(sample, accounts, SAMPLE_REVALUATION_RATES, { ...settings, accountCodes: ['4431'] });
  assert.deepEqual(report.issues, []);
  assert.ok(report.lines.length > 1);
  assert.ok(report.lines.every(line => line.account === '4431' && line.counterparty));
  const draft = revaluationDraft(report, 'BZ-FX-4431');
  assert.equal(journalDraftError(draft, accounts, []), '');
  assert.ok(draft.lines.some(line => line.account === '4431'));
});

test('revaluation settings omit explanatory copy and correspondence disclosure', () => {
  const view = readFileSync(new URL('../src/components/GlJournalRevaluationView.tsx', import.meta.url), 'utf8');
  assert.doesNotMatch(view, /Base currency:|Posted balances up to the selected date|Test records|Correspondence accounts|showCorrespondence/);
  assert.match(view, /Debit account/);
  assert.match(view, /Credit account/);
  assert.match(view, /revaluationSelectableAccounts\(accounts, journalWorkingRows\(rows\)\)/);
  assert.match(view, /const selected = selectedCodes\.filter/);
  assert.doesNotMatch(view, /Journal entry created · Unposted|onOpenJournal\(saved\.number\)/);
});

test('result periods belong to the calculated snapshot and preserve saved historical reports', () => {
  assert.deepEqual(revaluationResultRows(null), []);
  const report = calculateRevaluation([row('sale', '2410', 1100, 0, 1000, 0)], accounts, rates, settings);
  const persisted = JSON.stringify(report);
  const oldReport = JSON.parse(persisted);
  const resultRows = revaluationResultRows(oldReport);
  assert.equal(resultRows.length, oldReport.lines.length);
  assert.equal(resultRows[0].period, '2026-10');
  assert.equal(resultRows[0].revaluationDate, '2026-10-19');
  assert.equal(resultRows[0].id, oldReport.lines[0].id);
  assert.equal(JSON.stringify(oldReport), persisted);
  assert.equal(oldReport.fingerprint, report.fingerprint);
  assert.deepEqual(revaluationResultRows({ ...oldReport, date: '2026-09-30' }).map(line => [line.period, line.revaluationDate]), [['2026-09', '2026-09-30']]);
});

test('Run revaluation saves directly without a confirmation step and protects repeat runs', () => {
  const view = readFileSync(new URL('../src/components/GlJournalRevaluationView.tsx', import.meta.url), 'utf8');
  const journal = readFileSync(new URL('../src/components/CompanyGlJournalView.tsx', import.meta.url), 'utf8');
  assert.match(view, /if \(!result\.issues\.length && result\.lines\.some\(line => line\.amountMinor > 0\)\) onSave\(result\)/);
  assert.match(view, /disabled=\{!mayCreate \|\| !date \|\| !selected\.length\}/);
  assert.doesNotMatch(view, /Create journal entry|const save =|confirm\(|Journal entry created · Unposted/);
  assert.match(journal, /entry\.revaluation\?\.fingerprint === fresh\.fingerprint/);
  assert.match(journal, /if \(existing\) \{\s*setRefreshRevision\(value => value \+ 1\);\s*return existing\.number;/);
  assert.match(journal, /A revaluation journal already exists for these accounts and this date/);
  assert.match(journal, /fresh\.fingerprint !== report\.fingerprint/);
});

test('GL account bulk selection is opt-in, respects search and does not close the menu', () => {
  const field = readFileSync(new URL('../src/components/MultiSelectField.tsx', import.meta.url), 'utf8');
  const view = readFileSync(new URL('../src/components/GlJournalRevaluationView.tsx', import.meta.url), 'utf8');
  assert.match(field, /showSelectionActions = false/);
  assert.match(field, /\[\.\.\.new Set\(\[\.\.\.selected, \.\.\.filteredOptions\]\)\]/);
  assert.match(field, /selected\.filter\(option => !filteredOptions\.includes\(option\)\)/);
  assert.match(field, /'Select filtered' : 'Select all'/);
  assert.match(field, /'Clear filtered' : 'Clear all'/);
  assert.match(view, /label="GL accounts" required showSelectionActions/);
  assert.match(view, /key: 'period', label: 'Revaluation period', width: 175, visible: true/);
  assert.match(view, /storedColumns\.some\(column => column\.key === 'period'\)/);
  assert.match(view, /revaluationResultRows\(report\)/);
  assert.match(view, /As of \{line\.revaluationDate\}/);
});
