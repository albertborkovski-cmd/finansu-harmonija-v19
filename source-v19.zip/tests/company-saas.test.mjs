import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import test from 'node:test';
import ts from 'typescript';

const source = readFileSync(new URL('../src/lib/companySaas.ts', import.meta.url), 'utf8');
const { outputText } = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } });
const saas = await import(`data:text/javascript;base64,${Buffer.from(outputText).toString('base64')}`);
const { defaultCompanySaasPlan, parseCompanySaasPlan, validateCompanySaasPlan, companySaasUsage } = saas;

test('starts with the supplied SaaS plan and accepts its JSON form', () => {
  const supplied = { produktas: 'both', kainodara: 'docs', kiekis: '5000', kaina: '0.08', periodas: 'month', virsijimas: 'charge', moduliai: ['email', 'api'] };
  assert.deepEqual(defaultCompanySaasPlan(), supplied);
  assert.deepEqual(parseCompanySaasPlan(JSON.stringify(supplied)), supplied);
  assert.equal(validateCompanySaasPlan(supplied), null);
});

test('companies receive independent plan objects and module selections', () => {
  const alice = parseCompanySaasPlan(undefined);
  const bob = parseCompanySaasPlan(undefined);
  alice.kiekis = '8000';
  alice.moduliai.pop();
  assert.equal(bob.kiekis, '5000');
  assert.deepEqual(bob.moduliai, ['email', 'api']);
  const restored = parseCompanySaasPlan(JSON.stringify(alice));
  assert.deepEqual(restored, alice);
  assert.deepEqual(parseCompanySaasPlan(undefined), bob);
});

test('invalid stored settings fall back safely; empty module selections are preserved', () => {
  for (const invalid of [undefined, null, 'broken JSON', '[]', 'null']) assert.deepEqual(parseCompanySaasPlan(invalid), defaultCompanySaasPlan());
  assert.deepEqual(parseCompanySaasPlan({ moduliai: [] }).moduliai, []);
  assert.deepEqual(parseCompanySaasPlan({ moduliai: ['api', 'api', 'admin'] }).moduliai, ['api']);
  assert.equal(parseCompanySaasPlan({ kiekis: -3, kaina: Infinity }).kiekis, '5000');
  assert.equal(parseCompanySaasPlan({ kiekis: -3, kaina: Infinity }).kaina, '0.08');
});

test('supports active-user and per-company pricing without changing saved document-based plans', () => {
  assert.ok(saas.SAAS_PRICING.some(option => option.value === 'users' && option.label === 'Per active user'));
  assert.ok(saas.SAAS_PRICING.some(option => option.value === 'fixed' && option.label === 'Fixed fee per company'));
  for (const kainodara of ['docs', 'users', 'fixed']) {
    const plan = { ...defaultCompanySaasPlan(), kainodara };
    assert.deepEqual(parseCompanySaasPlan(JSON.stringify(plan)), plan);
    assert.equal(validateCompanySaasPlan(plan), null);
  }
});

test('all six modules can be selected, saved and restored with stable internal keys', () => {
  assert.deepEqual(saas.SAAS_MODULES.map(module => module.label), ['Email document collection', 'SharePoint', 'Dropbox', 'Google Drive', 'API integrations', 'Rivilė export']);
  const plan = { ...defaultCompanySaasPlan(), moduliai: saas.SAAS_MODULES.map(module => module.value) };
  assert.deepEqual(parseCompanySaasPlan(JSON.stringify(plan)), plan);
  assert.equal(validateCompanySaasPlan(plan), null);
  assert.deepEqual(parseCompanySaasPlan({ moduliai: ['email', 'api'] }).moduliai, ['email', 'api']);
  assert.ok(validateCompanySaasPlan({ ...plan, moduliai: ['unknown'] }));
});

test('requires an integer limit and a finite non-negative price', () => {
  for (const kiekis of ['', '0', '-1', '2.5', 'NaN', 'Infinity', '9007199254740992']) assert.ok(validateCompanySaasPlan({ ...defaultCompanySaasPlan(), kiekis }));
  for (const kaina of ['', '-1', 'abc', 'Infinity', '0.1234567']) assert.ok(validateCompanySaasPlan({ ...defaultCompanySaasPlan(), kaina }));
  assert.equal(validateCompanySaasPlan({ ...defaultCompanySaasPlan(), kaina: '0' }), null);
});

const document = (id, receive_date, company_id = 'alice', extra = {}) => ({ id, company_id, receive_date, ...extra });
const now = new Date(2026, 9, 27, 12);
const rows = [
  document('first', '2026-10-01'),
  document('last', '27.10.2026'),
  document('timestamp', new Date(2026, 9, 15, 12).toISOString()),
  document('fallback', '', 'alice', { created_at: '2026-10-02' }),
  document('first', '2026-10-01'),
  document('other-company', '2026-10-10', 'bob'),
  document('unassigned', '2026-10-10', undefined),
  document('previous-month', '2026-09-30'),
  document('future', '2026-10-28'),
  document('future-month', '2026-11-01'),
  document('bad-date', '2026-10-32'),
  document('bad-dotted-date', '31.09.2026'),
  document('bad-string', 'not a date'),
];
// Explicitly unset, since the document helper intentionally defaults to Alice.
rows.find(row => row.id === 'unassigned').company_id = undefined;

test('usage is company-scoped, deduplicated and based on received dates within the current period', () => {
  const result = companySaasUsage('alice', rows, defaultCompanySaasPlan(), now);
  assert.equal(result.used, 4);
  assert.equal(result.remaining, 4996);
  assert.equal(result.percentage, 0.1);
  assert.equal(result.from, '2026-10-01');
  assert.equal(result.to, '2026-10-31');
  assert.equal(companySaasUsage('bob', rows, defaultCompanySaasPlan(), now).used, 1);
  assert.equal(companySaasUsage('', rows, defaultCompanySaasPlan(), now).used, 0);
});

test('yearly periods include previous months but not previous years or future documents', () => {
  const result = companySaasUsage('alice', [...rows, document('old', '2025-12-31')], { ...defaultCompanySaasPlan(), periodas: 'year' }, now);
  assert.equal(result.used, 5);
  assert.equal(result.from, '2026-01-01');
  assert.equal(result.to, '2026-12-31');
});

test('handles overage, zero usage and invalid draft limits without negative amounts or NaN', () => {
  const plan = { ...defaultCompanySaasPlan(), kiekis: '2' };
  assert.deepEqual(companySaasUsage('alice', rows, plan, now), { from: '2026-10-01', to: '2026-10-31', used: 4, remaining: 0, exceeded: 2, percentage: 200, progress: 100 });
  assert.equal(companySaasUsage('alice', [], plan, now).progress, 0);
  const invalid = companySaasUsage('alice', rows, { ...plan, kiekis: '' }, now);
  assert.equal(invalid.remaining, null);
  assert.equal(invalid.percentage, null);
  assert.equal(invalid.progress, 0);
});

test('handles leap years and December boundaries', () => {
  const plan = defaultCompanySaasPlan();
  assert.equal(companySaasUsage('alice', [], plan, new Date(2028, 1, 10)).to, '2028-02-29');
  assert.equal(companySaasUsage('alice', [], plan, new Date(2026, 11, 10)).to, '2026-12-31');
});

test('Save persists through the real local query contract and only changes the chosen company', async () => {
  const require = createRequire(import.meta.url);
  const adapterSource = readFileSync(new URL('../src/lib/supabase.ts', import.meta.url), 'utf8');
  const ast = ts.createSourceFile('supabase.ts', adapterSource, ts.ScriptTarget.Latest, true);
  const querySource = ast.statements.find(statement => ts.isClassDeclaration(statement) && statement.name?.text === 'LocalQuery').getText(ast);
  const queryCode = ts.transpileModule(querySource, { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText;
  let stored = [{ id: 'alice', name: 'Alice', company_code: 'A', client_notes: 'Keep this' }, { id: 'bob', name: 'Bob', saas_settings: '{"kiekis":"100"}' }];
  const originalBob = structuredClone(stored[1]);
  const LocalQuery = new Function('readTable', 'writeTable', queryCode + '\nreturn LocalQuery;')(
    async () => structuredClone(stored),
    async (_table, rows) => { stored = structuredClone(rows); },
  );
  const hooks = [];
  let cursor = 0;
  const react = {
    ...require('react'),
    useId: () => 'saas-test', useEffect() {}, useMemo: callback => callback(),
    useState(initial) {
      const index = cursor++;
      if (!(index in hooks)) hooks[index] = typeof initial === 'function' ? initial() : initial;
      return [hooks[index], value => { hooks[index] = typeof value === 'function' ? value(hooks[index]) : value; }];
    },
  };
  const componentCode = ts.transpileModule(readFileSync(new URL('../src/components/CompanySaasSection.tsx', import.meta.url), 'utf8'), {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX },
  }).outputText;
  const audit = [];
  const imports = {
    react, '../lib/companySaas': saas,
    '../lib/supabase': { supabase: { from: table => new LocalQuery(table) }, recordAdministrativeAction: async (...args) => { audit.push(args); } },
    './PageHeader': { PageActionButton: 'PageActionButton' },
    './SearchableSelect': { default: 'SearchableSelect' }, './MultiSelectField': { default: 'MultiSelectField' },
  };
  const module = { exports: {} };
  new Function('require', 'module', 'exports', componentCode)(id => imports[id] ?? require(id), module, module.exports);
  let savedCompany;
  const render = () => { cursor = 0; return module.exports.default({ company: stored[0], onCompanyUpdated: company => { savedCompany = company; } }); };
  function find(tree, predicate) {
    if (!tree || typeof tree !== 'object') return null;
    if (predicate(tree)) return tree;
    for (const child of [tree.props?.children].flat(Infinity)) { const result = find(child, predicate); if (result) return result; }
    return null;
  }
  const save = find(render(), element => element.type === 'PageActionButton' && element.props.children === 'Save SaaS settings');
  assert.equal(save.props.disabled, false);
  await save.props.onClick();
  assert.deepEqual(JSON.parse(stored[0].saas_settings), defaultCompanySaasPlan());
  assert.equal(stored[0].client_notes, 'Keep this');
  assert.deepEqual(stored[1], originalBob);
  assert.equal(savedCompany.saas_settings, stored[0].saas_settings);
  assert.equal(audit[0][0], 'alice');
  assert.equal(find(render(), element => element.type === 'PageActionButton' && element.props.children === 'Save SaaS settings').props.disabled, true);

  find(render(), element => element.type === 'SearchableSelect' && element.props.ariaLabel === 'SaaS pricing model').props.onChange('users');
  find(render(), element => element.type === 'MultiSelectField').props.onChange(saas.SAAS_MODULES.map(module => module.label));
  assert.ok(find(render(), element => element.type === 'label' && element.props.children[0] === 'Price per active user (EUR)'));
  assert.equal(find(render(), element => element.props?.children === 'Unsaved changes'), null);
  const refreshButton = find(render(), element => element.type === 'PageActionButton' && element.props.ariaLabel === 'Refresh SaaS usage');
  assert.equal(refreshButton.props.children, 'Refresh');
  assert.equal(refreshButton.props.iconOnly, undefined);
  await find(render(), element => element.type === 'PageActionButton' && element.props.children === 'Save SaaS settings').props.onClick();
  assert.equal(JSON.parse(stored[0].saas_settings).kainodara, 'users');
  assert.deepEqual(JSON.parse(stored[0].saas_settings).moduliai, saas.SAAS_MODULES.map(module => module.value));
  assert.deepEqual(stored[1], originalBob);
});
