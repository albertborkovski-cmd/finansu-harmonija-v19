import { useMemo, useState, type ReactNode } from "react";
import { Check } from "lucide-react";
import type { Company } from "../lib/supabase";
import { PageHeader } from "./PageHeader";
import OcrBreadcrumb from "./OcrBreadcrumb";
import OcrSearchField from "./OcrSearchField";

export default function OcrDocumentsWorkspace({
  title,
  organizations,
  selectedIds,
  onOrganizationsChange,
  singleOrganization = false,
  embedded = false,
  children,
}: {
  title: string;
  organizations: Company[];
  selectedIds: string[];
  onOrganizationsChange: (ids: string[]) => void;
  singleOrganization?: boolean;
  embedded?: boolean;
  children: ReactNode;
}) {
  return (
    <div className={`ocr-documents-workspace flex min-w-0 flex-col bg-white font-montserrat text-[#10233A] ${embedded ? "min-h-full gap-4" : "h-dvh min-h-0 gap-4 overflow-hidden px-4 py-10 sm:px-8 lg:px-[56px]"}`}>
      {!embedded && <PageHeader title={title} />}
      {!embedded && <OcrBreadcrumb items={["All documents", title]} />}
      <div className="flex min-h-0 flex-1 flex-col items-stretch gap-4 lg:flex-row">
        {!embedded && (
          <OrganizationSidebar
            organizations={organizations}
            selectedIds={selectedIds}
            onChange={onOrganizationsChange}
            singleOrganization={singleOrganization}
          />
        )}
        <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-3">
          {children}
        </div>
      </div>
    </div>
  );
}

function OrganizationSidebar({
  organizations,
  selectedIds,
  onChange,
  singleOrganization = false,
}: {
  organizations: Company[];
  selectedIds: string[];
  onChange: (ids: string[]) => void;
  singleOrganization?: boolean;
}) {
  const [organizationQuery, setOrganizationQuery] = useState("");
  const allSelected =
    organizations.length > 0 && selectedIds.length === organizations.length;
  const visibleOrganizations = useMemo(() => {
    const normalizedQuery = organizationQuery.trim().toLocaleLowerCase();
    if (!normalizedQuery) return organizations;
    return organizations.filter((organization) =>
      organization.name.toLocaleLowerCase().includes(normalizedQuery),
    );
  }, [organizationQuery, organizations]);

  const toggleOrganization = (id: string) => {
    if (singleOrganization) {
      onChange([id]);
      return;
    }
    const next = selectedIds.includes(id)
      ? selectedIds.filter((selectedId) => selectedId !== id)
      : [...selectedIds, id];
    onChange(next);
  };

  return (
    <aside className="flex max-h-[240px] w-full flex-shrink-0 flex-col self-start overflow-hidden rounded-lg border border-[#D3E1EC] bg-white lg:max-h-full lg:w-[224px]">
      <div className="shrink-0 border-b border-[#E5EDF9] px-4 pb-3 pt-4">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-montserrat text-[14px] font-semibold text-[#10233A]">
            Organizations
          </h2>
          <span className="flex h-6 min-w-10 items-center justify-center rounded-full bg-[#E7F4F9] px-2 font-montserrat text-[11px] font-semibold text-[#007EA7]">
            {selectedIds.length}/{organizations.length}
          </span>
        </div>
        <p className="mt-1 font-montserrat text-[11px] font-medium leading-[16px] text-[#7288A3]">
          {singleOrganization ? "Choose an organization to display" : "Choose which organizations to display"}
        </p>
        <OcrSearchField
          ariaLabel="Search organizations"
          value={organizationQuery}
          onChange={setOrganizationQuery}
          className="mt-3 !w-full !min-w-0 !max-w-full"
        />
      </div>
      <div className="flex min-h-0 flex-col p-2">
        {!singleOrganization && <>
        <button
          type="button"
          aria-pressed={allSelected}
          data-static-selection
          onClick={() => onChange(
            allSelected ? [] : organizations.map((organization) => organization.id),
          )}
          className={`flex min-h-10 w-full shrink-0 items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors ${allSelected ? "bg-[#E7F4F9]" : "hover:bg-[#F2F7FC]"}`}
        >
          <SelectorCheck checked={allSelected} />
          <span className="min-w-0 flex-1 font-montserrat text-[12px] font-semibold text-[#10233A]">
            All organizations
          </span>
          <span className="font-montserrat text-[11px] font-medium text-[#7288A3]">
            {organizations.length}
          </span>
        </button>
        <div className="mx-2 my-2 h-px shrink-0 bg-[#E5EDF9]" />
        </>}
        <div className="min-h-0 max-h-[calc(100dvh-250px)] overflow-y-auto overscroll-y-contain pr-0.5">
          <div className="flex flex-col gap-0.5">
            {visibleOrganizations.map((organization) => {
              const checked = selectedIds.includes(organization.id);
              const initials = organization.name
                .trim()
                .split(/\s+/)
                .slice(0, 2)
                .map((part) => part.charAt(0).toLocaleUpperCase())
                .join("");
              return (
                <button
                  type="button"
                  key={organization.id}
                  aria-pressed={checked}
                  data-static-selection
                  onClick={() => toggleOrganization(organization.id)}
                  className={`group flex min-h-11 w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-left transition-colors ${checked && (singleOrganization || !allSelected) ? "bg-[#E5EDF9]" : "hover:bg-[#F2F7FC]"}`}
                >
                  <SelectorCheck checked={checked} />
                  <span className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-[#E5EDF9] font-montserrat text-[10px] font-semibold text-[#42627E] group-hover:bg-white">
                    {initials || "—"}
                  </span>
                  <span className="min-w-0 flex-1 truncate font-montserrat text-[12px] font-medium text-[#10233A]">
                    {organization.name}
                  </span>
                </button>
              );
            })}
            {visibleOrganizations.length === 0 && (
              <div className="px-3 py-6 text-center font-montserrat text-[11px] font-medium text-[#7288A3]">
                No organizations found
              </div>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}

function SelectorCheck({ checked }: { checked: boolean }) {
  return (
    <span className={`flex h-[18px] w-[18px] flex-shrink-0 items-center justify-center rounded-[6px] border ${checked ? "border-[#007EA7] bg-[#007EA7]" : "border-[#A1B6C6] bg-white"}`}>
      {checked && <Check size={12} strokeWidth={2.5} className="text-white" />}
    </span>
  );
}


