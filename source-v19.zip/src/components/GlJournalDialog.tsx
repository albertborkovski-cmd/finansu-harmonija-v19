import { useEffect, useId, useRef, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';

export default function GlJournalDialog({ title, subtitle, children, footer, onClose, wide = false, printable = false }: {
  title: string; subtitle?: string; children: ReactNode; footer?: ReactNode; onClose: () => void; wide?: boolean; printable?: boolean;
}) {
  const titleId = useId();
  const ref = useRef<HTMLDivElement>(null);
  const close = useRef(onClose); close.current = onClose;
  useEffect(() => {
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden'; ref.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        if (ref.current?.querySelector('[aria-expanded="true"]')) return;
        event.preventDefault(); close.current();
      }
      if (event.key !== 'Tab') return;
      const controls = Array.from(ref.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), textarea:not(:disabled), a[href], [tabindex="0"]') || []).filter(item => item.getClientRects().length);
      const first = controls[0], last = controls[controls.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === ref.current)) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || document.activeElement === ref.current)) { event.preventDefault(); first?.focus(); }
    };
    window.addEventListener('keydown', onKey, true);
    return () => { window.removeEventListener('keydown', onKey, true); document.body.style.overflow = overflow; if (previous?.isConnected) previous.focus({ preventScroll: true }); };
  }, []);
  return createPortal(<div data-gl-journal-print-overlay={printable || undefined} className="fixed inset-0 z-[240] flex items-center justify-center bg-[#10233A]/30 p-4">
    <div ref={ref} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1} className={`gl-journal-dialog flex max-h-[calc(100dvh-32px)] w-full flex-col rounded-xl bg-white font-montserrat text-[#10233A] shadow-xl outline-none ${wide ? 'max-w-[1500px]' : 'max-w-[620px]'}`}>
      <header className="flex shrink-0 items-start justify-between gap-4 border-b border-[#E5EDF9] px-6 py-4"><div><h2 id={titleId} className="text-[22px] font-semibold">{title}</h2>{subtitle && <p className="mt-1 text-[12px] text-[#7288A3]">{subtitle}</p>}</div><button className="gl-journal-no-print text-[#7288A3] hover:text-[#007EA7]" type="button" aria-label={`Close ${title}`} onClick={onClose}><X size={20} /></button></header>
      <div className="gl-journal-dialog-content min-h-0 overflow-auto px-6 py-5">{children}</div>
      {footer && <footer className="gl-journal-no-print flex shrink-0 items-center justify-end gap-2 border-t border-[#E5EDF9] px-6 py-4">{footer}</footer>}
    </div>
  </div>, document.body);
}
