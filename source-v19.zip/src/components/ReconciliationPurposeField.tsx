import { useEffect, useRef, useState } from 'react';

export default function ReconciliationPurposeField({ value, documentNumber, disabled, onSave }: {
  value: string;
  documentNumber: string;
  disabled: boolean;
  onSave: (value: string) => void;
}) {
  const [draft, setDraft] = useState(value);
  const cancelled = useRef(false);
  useEffect(() => setDraft(value), [value]);
  return <input
    aria-label={`Payment purpose for ${documentNumber}`}
    title={draft || 'Click to enter payment purpose'}
    value={draft}
    placeholder="—"
    disabled={disabled}
    onChange={event => setDraft(event.target.value)}
    onFocus={() => { cancelled.current = false; }}
    onBlur={() => {
      if (!cancelled.current && draft.trim() !== value) onSave(draft.trim());
    }}
    onKeyDown={event => {
      if (event.key === 'Enter') { event.preventDefault(); event.currentTarget.blur(); }
      if (event.key === 'Escape') {
        event.preventDefault(); cancelled.current = true; setDraft(value); event.currentTarget.blur();
      }
    }}
    className="h-7 w-full min-w-0 rounded border border-transparent bg-transparent px-1 text-[12px] font-normal text-[#10233A] outline-none placeholder:text-[#7288A3] hover:border-[#D3E1EC] focus:border-[#007EA7] focus:bg-white disabled:cursor-default disabled:hover:border-transparent"
  />;
}
