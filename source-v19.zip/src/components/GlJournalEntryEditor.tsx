import { useMemo, useState, type ReactNode } from 'react';
import { Plus, Save, Trash2 } from 'lucide-react';
import { applyJournalDocumentAnalytics, journalDocumentAnalytics, JOURNAL_ANALYTICS_KEYS, draftJournalTotals, emptyJournalLine, journalDraftError, journalDraftLineSide, setJournalDraftLineSide, parseJournalMinor, type JournalAccountOption, type JournalDraft, type JournalDraftLine } from '../lib/glJournalDrafts';
import { journalDate, type GlJournalRow } from '../lib/glJournal';
import { PageActionButton } from './PageHeader';
import ScheduleDatePicker from './ScheduleDatePicker';
import SearchableSelect from './SearchableSelect';
import GlJournalDocumentLayout, { JournalCorrespondenceTable, JournalDocumentFields, JournalDocumentTotals, JournalEntryHeader, journalDocumentFieldClass as fieldClass, type JournalDocumentFieldKey } from './GlJournalDocumentLayout';

const amount = (minor: number) => (minor / 100).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export default function GlJournalEntryEditor({ initialDraft, mode, companyName, createdBy, sourceRow, accounts, currencies, existingNumbers, onSave, onClose }: {
  initialDraft: JournalDraft; mode: 'new' | 'copy' | 'edit'; companyName: string; accounts: JournalAccountOption[]; currencies: string[]; existingNumbers: string[];
  createdBy: string; sourceRow?: GlJournalRow;
  onSave: (draft: JournalDraft) => void; onClose: () => void;
}) {
  const [draft, setDraft] = useState(() => ({
    ...initialDraft,
    lines: initialDraft.lines.map((line, index) => line.debit || line.credit ? line : { ...line, ...(index === 0 ? { debit: '0' } : { credit: '0' }) }),
  }));
  const [documentAnalytics, setDocumentAnalytics] = useState(() => journalDocumentAnalytics(initialDraft));
  const [saveError, setSaveError] = useState('');
  const [selectedLineId, setSelectedLineId] = useState(() => initialDraft.lines.find(line => line.id === sourceRow?.id || line.id === `copy-${sourceRow?.id}-d` || line.id === `copy-${sourceRow?.id}-c`)?.id || initialDraft.lines[0]?.id || '');
  const selectedLine = draft.lines.find(line => line.id === selectedLineId) || draft.lines[0];
  const selectedIndex = selectedLine ? draft.lines.indexOf(selectedLine) : -1;
  const side = selectedLine ? journalDraftLineSide(selectedLine) : 'Debit';
  const opposite = side === 'Debit' ? 'Credit' : 'Debit';
  const correspondingLines = draft.lines.filter(line => line.id !== selectedLine?.id && journalDraftLineSide(line) !== side);
  const title = mode === 'edit' ? 'Edit journal entry' : mode === 'copy' ? 'Copy journal entry' : 'New journal entry';
  const totals = draftJournalTotals(draft);
  const validation = documentAnalytics.conflicts.length ? `Set one document value for: ${documentAnalytics.conflicts.join(', ')}. Previous lines contain different values.` : journalDraftError(draft, accounts, existingNumbers);
  const accountOptions = useMemo(() => accounts.map(account => ({ value: account.code, label: `${account.code} · ${account.name}` })), [accounts]);
  const update = <K extends keyof JournalDraft>(key: K, value: JournalDraft[K]) => { setDraft(current => ({ ...current, [key]: value })); setSaveError(''); };
  const updateLine = (id: string, key: keyof JournalDraftLine, value: string) => {
    setDraft(current => ({ ...current, lines: current.lines.map(line => line.id === id ? { ...line, [key]: value } : line) }));
    setSaveError('');
  };
  const setSide = (id: string, value: string) => {
    if (value !== 'Debit' && value !== 'Credit') return;
    setDraft(current => ({ ...current, lines: current.lines.map(line => line.id === id ? setJournalDraftLineSide(line, value) : line) }));
    setSaveError('');
  };
  const addLine = () => {
    const line = { ...emptyJournalLine(crypto.randomUUID()), counterparty: selectedLine?.counterparty || '', ...(opposite === 'Credit' ? { credit: '0' } : { debit: '0' }) };
    update('lines', [...draft.lines, line]);
    if (!selectedLine) setSelectedLineId(line.id);
  };
  const removeLine = (id: string) => {
    const lines = draft.lines.filter(line => line.id !== id);
    update('lines', lines);
    if (selectedLine?.id === id) setSelectedLineId(lines[Math.min(selectedIndex, lines.length - 1)]?.id || '');
  };
  const save = () => {
    if (validation) { setSaveError(validation); return; }
    try { onSave(applyJournalDocumentAnalytics(draft, documentAnalytics.values)); } catch (error) { setSaveError(error instanceof Error ? error.message : 'The journal entry could not be saved.'); }
  };
  const selectedAmount = selectedLine ? (side === 'Debit' ? selectedLine.debit : selectedLine.credit) : '';
  const selectedMinor = parseJournalMinor(selectedAmount);
  const lineInput = (key: 'counterparty' | 'costCenter' | 'comment') => <input aria-label={`Selected entry ${key}`} value={selectedLine?.[key] || ''} disabled={!selectedLine} onChange={event => selectedLine && updateLine(selectedLine.id, key, event.target.value)} className={fieldClass} />;
  const dimensionControls = Object.fromEntries(JOURNAL_ANALYTICS_KEYS.map(key => [key,
    <input key={key} aria-label={`Journal ${key}`} value={documentAnalytics.values[key]} placeholder={documentAnalytics.conflicts.includes(key) ? 'Choose one value for this document' : ''} onChange={event => { const value = event.target.value; setDocumentAnalytics(current => ({ values: { ...current.values, [key]: value }, conflicts: current.conflicts.filter(item => item !== key) })); setSaveError(''); }} className={fieldClass} />,
  ])) as Partial<Record<JournalDocumentFieldKey, ReactNode>>;

  return <GlJournalDocumentLayout title={title} number={draft.number} companyName={companyName} fileUrl={sourceRow?.document.imageUrl} onClose={onClose}
    actions={<PageActionButton icon={<Save size={15} />} disabled={Boolean(validation)} onClick={save}>{mode === 'edit' ? 'Save changes' : 'Save journal entry'}</PageActionButton>}
    details={<>
      <JournalEntryHeader side={side} status={mode === 'edit' ? sourceRow?.postingStatus || 'Unposted' : 'Unposted'} index={selectedIndex} count={draft.lines.length}
        onPrevious={() => setSelectedLineId(draft.lines[selectedIndex - 1].id)} onNext={() => setSelectedLineId(draft.lines[selectedIndex + 1].id)}
        action={selectedLine && <button type="button" aria-label="Remove selected GL entry" title="Remove line from this draft" onClick={() => removeLine(selectedLine.id)} className="text-[#7288A3] hover:text-[#E5484D]"><Trash2 size={15} /></button>} />
      <JournalDocumentFields values={{
        counterpartyCode: sourceRow?.counterparty === selectedLine?.counterparty ? sourceRow?.document.counterpartyCode : '',
        internalNumber: mode === 'edit' ? sourceRow?.internalNumber || draft.number : draft.number,
        documentDate: mode === 'edit' && sourceRow?.document.documentDate ? journalDate(sourceRow.document.documentDate) : draft.date,
        dueDate: mode === 'edit' && sourceRow?.document.dueEndDate ? journalDate(sourceRow.document.dueEndDate) : '',
        documentType: mode === 'edit' ? sourceRow?.documentType || 'Accounting note' : 'Accounting note',
        exchangeRate: draft.currency === 'EUR' ? '1.000000' : '',
        amountEur: draft.currency === 'EUR' && selectedMinor !== null ? amount(selectedMinor) : '',
        createdBy, status: 'Active',
      }} controls={{
        ...dimensionControls,
        counterparty: lineInput('counterparty'),
        number: <input aria-label="Journal document number" required value={draft.number} onChange={event => update('number', event.target.value)} className={fieldClass} />,
        operationDate: <div className="[&>div>button]:h-10 [&>div>button]:rounded-md [&>div>button]:px-3 [&>div>button]:text-[12px]"><ScheduleDatePicker ariaLabel="Journal operation date" value={draft.date} onChange={value => update('date', value)} placeholder="YYYY-MM-DD" /></div>,
        operationType: <SearchableSelect portalMenu ariaLabel="Selected entry operation type" value={side} disabled={!selectedLine} options={['Debit', 'Credit']} onChange={value => selectedLine && setSide(selectedLine.id, value)} className={fieldClass + ' pr-9'} />,
        account: <SearchableSelect portalMenu ariaLabel="Edit selected GL account" value={selectedLine?.account || ''} disabled={!selectedLine} options={accountOptions} onChange={value => selectedLine && updateLine(selectedLine.id, 'account', value)} className={fieldClass + ' pr-9'} />,
        currency: <SearchableSelect portalMenu ariaLabel="Journal currency" value={draft.currency} options={currencies} onChange={value => update('currency', value)} className={fieldClass + ' pr-9'} />,
        amount: <input aria-label="Selected entry amount" value={selectedAmount} inputMode="decimal" disabled={!selectedLine} onChange={event => selectedLine && updateLine(selectedLine.id, side === 'Debit' ? 'debit' : 'credit', event.target.value || '0')} className={fieldClass} />,
        costCenter: lineInput('costCenter'),
        comment: <textarea aria-label="Selected entry comment" rows={3} value={selectedLine?.comment || ''} disabled={!selectedLine} onChange={event => selectedLine && updateLine(selectedLine.id, 'comment', event.target.value)} className={fieldClass + ' h-auto resize-none py-2 leading-5'} />,
      }} />
    </>}
    correspondence={<>
      <JournalCorrespondenceTable title={opposite} count={correspondingLines.length} editable actions={<PageActionButton icon={<Plus size={14} />} onClick={addLine}>Add line</PageActionButton>}>
        {correspondingLines.map(line => {
          const index = draft.lines.indexOf(line) + 1;
          const key = journalDraftLineSide(line) === 'Credit' ? 'credit' : 'debit';
          const minor = parseJournalMinor(line[key]);
          return <tr key={line.id} className="align-top odd:bg-white even:bg-[#F8FDFF] hover:bg-[#E7F4F9]">
            <td className="border-b border-[#E5EDF9] p-2"><SearchableSelect portalMenu ariaLabel={`Line ${index} GL account`} value={line.account} options={accountOptions} onChange={value => updateLine(line.id, 'account', value)} className={fieldClass + ' pr-9'} /><button type="button" onClick={() => setSelectedLineId(line.id)} className="mt-1 text-[10px] text-[#007EA7] hover:underline">Edit line details</button></td>
            <td className="border-b border-[#E5EDF9] p-2"><input aria-label={`Line ${index} amount`} inputMode="decimal" value={line[key]} onChange={event => updateLine(line.id, key, event.target.value || '0')} className={fieldClass + ' text-right tabular-nums'} /><span className="mt-0.5 block text-right text-[10px] text-[#7288A3]">{draft.currency}</span></td>
            <td className="border-b border-[#E5EDF9] p-2"><input aria-label={`Line ${index} counterparty`} value={line.counterparty} onChange={event => updateLine(line.id, 'counterparty', event.target.value)} className={fieldClass} /></td>
            <td className="border-b border-[#E5EDF9] px-3 py-3 text-right tabular-nums">{draft.currency === 'EUR' && minor !== null ? amount(minor) : '—'}</td>
            <td className="border-b border-[#E5EDF9] px-3 py-3 text-[#7288A3]">—</td>
            <td className="border-b border-[#E5EDF9] p-2"><input aria-label={`Line ${index} comment`} value={line.comment} onChange={event => updateLine(line.id, 'comment', event.target.value)} className={fieldClass} /></td>
            <td className="border-b border-[#E5EDF9] p-1 text-right"><button type="button" aria-label={`Remove line ${index}`} title="Remove line from this draft" onClick={() => removeLine(line.id)} className="inline-flex h-8 w-8 items-center justify-center text-[#7288A3] hover:text-[#E5484D]"><Trash2 size={15} /></button></td>
          </tr>;
        })}
      </JournalCorrespondenceTable>
      <JournalDocumentTotals totals={[{ currency: draft.currency, debit: totals.debit / 100, credit: totals.credit / 100 }]}>
        <p className={`mt-3 border-t border-[#E5EDF9] pt-3 text-[12px] ${totals.debit === totals.credit ? 'text-[#087A5B]' : 'text-[#C45100]'}`}>Difference <strong>{amount(totals.debit - totals.credit)} {draft.currency}</strong></p>
      </JournalDocumentTotals>
      <p role={saveError ? 'alert' : undefined} className={`text-[11px] leading-5 ${saveError || validation ? 'text-[#C45100]' : 'text-[#7288A3]'}`}>{saveError || validation || (mode === 'edit' ? 'Changes are saved in this browser. No accounting postings are sent.' : 'Saved as an unposted journal entry in this browser. No accounting postings are sent.')}</p>
    </>} />;
}
