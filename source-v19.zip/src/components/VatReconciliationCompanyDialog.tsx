import { useEffect, useState } from 'react';
import { supabase, type Company } from '../lib/supabase';
import { AUTH_SESSION_KEY } from '../lib/currentUser';
import { parseSession } from '../lib/accessControl';
import { canAccessAssignedOrganization } from '../lib/linkedSettingsData';
import type { GlJournalRow } from '../lib/glJournal';
import type { JournalAccountOption } from '../lib/glJournalDrafts';
import GlJournalClosingDialog from './GlJournalClosingDialog';
import GlJournalDialog from './GlJournalDialog';
import SearchableSelect from './SearchableSelect';

export type VatCompanyData = { rows: GlJournalRow[]; accounts: JournalAccountOption[]; testData?: boolean };

export default function VatReconciliationCompanyDialog({ company, initialPeriod, loadCompanyData, onClose }: {
  company: Company; initialPeriod: { from: string; to: string }; loadCompanyData: (company: Company) => Promise<VatCompanyData>; onClose: () => void;
}) {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [selectedId, setSelectedId] = useState(company.id);
  const [period, setPeriod] = useState(initialPeriod);
  const [data, setData] = useState<{ company: Company; data: VatCompanyData } | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const result = await supabase.from('companies').select('*').order('name', { ascending: true });
        if (result.error) throw new Error(result.error.message);
        const session = parseSession(window.localStorage.getItem(AUTH_SESSION_KEY));
        const accessible = (result.data as unknown as Company[] || []).filter(item => session && canAccessAssignedOrganization(item, session));
        if (!cancelled) {
          setCompanies(accessible);
          if (!accessible.some(item => item.id === company.id)) setError(accessible.length ? 'Select an accessible company from the list.' : 'No accessible companies found.');
        }
      } catch { if (!cancelled) setError('Company contacts could not be loaded. Close and try again.'); }
    })();
    return () => { cancelled = true; };
  }, [company.id]);
  useEffect(() => {
    let cancelled = false;
    const selected = companies.find(item => item.id === selectedId);
    if (!selected) return;
    setData(null); setError('');
    void loadCompanyData(selected).then(result => { if (!cancelled) setData({ company: selected, data: result }); }).catch(reason => { if (!cancelled) setError(reason instanceof Error ? reason.message : 'Could not load company GL entries.'); });
    return () => { cancelled = true; };
  }, [companies, selectedId, loadCompanyData]);
  const companySelect = <div className="mb-5"><div className="mb-2 text-[12px] text-[#7288A3]">Company · Email</div><SearchableSelect portalMenu ariaLabel="VAT company" value={selectedId} options={companies.map(item => ({ value: item.id, label: `${item.name} · ${item.email?.trim() || 'Email not configured'}` }))} onChange={setSelectedId} /></div>;
  if (!data || data.company.id !== selectedId) return <GlJournalDialog title="VAT reconciliation" onClose={onClose}>{companySelect}<p role={error ? 'alert' : 'status'} className="text-[13px] text-[#7288A3]">{error || (companies.length ? 'Loading company GL entries…' : 'Loading accessible companies…')}</p></GlJournalDialog>;
  return <GlJournalClosingDialog key={data.company.id} emailOnly companyId={data.company.id} companyName={data.company.name} initialRecipient={data.company.email} kind="vat" initialPeriod={period} onPeriodChange={setPeriod} rows={data.data.rows} accounts={data.data.accounts} testData={data.data.testData} companySelection={companySelect} onClose={onClose} />;
}
