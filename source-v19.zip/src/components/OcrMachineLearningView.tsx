import { useEffect, useMemo, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, ChevronDown, ChevronUp, ListChecks, Pause, Play, X } from 'lucide-react';
import { PageActionButton, PageHeader } from './PageHeader';
import OcrBreadcrumb from './OcrBreadcrumb';
import OcrSearchField from './OcrSearchField';
import SearchableSelect from './SearchableSelect';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import { ColumnSettingsButton } from './ScopedActionButtons';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import RefreshAllButton from './RefreshAllButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import TablePagination from './TablePagination';
import { TABLE_BATCH_SIZE } from '../lib/tablePaging';
import { usePersistentState } from '../hooks/usePersistentState';
import { RowDeleteButton } from './DeleteButtons';
import { WorkspaceDocumentEditor } from './WorkspaceView';
import { LEARNING_FIELDS, learnedRows, type LearnedRow, type LearningEvidence } from '../lib/ocrLearning';
import { changeLearningState, learningPermissions, loadLearningStore, OCR_LEARNING_CHANGED, OCR_LEARNING_KEY } from '../lib/ocrLearningStore';

const COLUMNS: ColConfig[] = [
  { key: 'companyName', label: 'Client', width: 210, visible: true },
  { key: 'field', label: 'Field', width: 160, visible: true },
  { key: 'supplierKey', label: 'Supplier key', width: 200, visible: true },
  { key: 'vatRate', label: 'VAT rate', width: 100, visible: true },
  { key: 'value', label: 'Value the system will use', width: 220, visible: true },
  { key: 'status', label: 'Will it be used?', width: 180, visible: true },
  { key: 'consistency', label: 'Consistency', width: 130, visible: true },
  { key: 'total', label: 'Times seen', width: 120, visible: true },
  { key: 'lastSeen', label: 'Last seen', width: 180, visible: true },
];
const dateTime = (value: string) => new Date(value).toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' });
const EMPTY_FILTERS = { field: '', client: '', supplier: '' };
const INPUT = 'h-[38px] w-full rounded-lg border border-[#D3E1EC] bg-white px-3 text-[12px] text-[#10233A] outline-none placeholder:text-[#A1B6C6] focus:border-[#007EA7]';

function LearningStatus({ row }: { row: LearnedRow }) {
  const ready = row.status === 'Used automatically';
  return <span className={`inline-flex max-w-full items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-semibold ${ready ? 'bg-[#EAF8F2] text-[#087A55]' : row.status === 'Needs review' ? 'bg-[#FFF8E5] text-[#9A6700]' : 'bg-[#E5EDF9] text-[#7288A3]'}`}>
    {ready ? <CheckCircle2 size={13} /> : row.status === 'Needs review' ? <AlertTriangle size={13} /> : <Pause size={13} />}<span className="truncate">{row.status}</span>
  </span>;
}

export default function OcrMachineLearningView({ onOpenReviewQueue }: { onOpenReviewQueue?: () => void }) {
  const [store, setStore] = useState(loadLearningStore);
  const [query, setQuery] = useState('');
  const [draftFilters, setDraftFilters] = useState(EMPTY_FILTERS);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [columns, setColumns] = usePersistentState<ColConfig[]>('finansu-harmonija:v19:ocr:learning-columns', COLUMNS);
  const [showColumns, setShowColumns] = useState(false);
  const [page, setPage] = useState(1);
  const [expandedHistory, setExpandedHistory] = useState<Set<string>>(new Set());
  const [evidence, setEvidence] = useState<LearningEvidence | null>(null);
  const [reviewDocument, setReviewDocument] = useState<LearningEvidence | null>(null);
  const [forgetRow, setForgetRow] = useState<LearnedRow | null>(null);
  const [notice, setNotice] = useState('');
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const { startResize } = useColumnResize(columns, setColumns);
  const permissions = learningPermissions();
  const rows = useMemo(() => learnedRows(store), [store]);
  const filtered = useMemo(() => rows.filter(row => {
    if (filters.field && row.field !== filters.field) return false;
    if (filters.client && !row.companyName.toLocaleLowerCase().includes(filters.client.toLocaleLowerCase().trim())) return false;
    if (filters.supplier && !`${row.supplierKey} ${row.supplierName}`.toLocaleLowerCase().includes(filters.supplier.toLocaleLowerCase().trim())) return false;
    return !query.trim() || [row.companyName, row.supplierKey, row.supplierName, LEARNING_FIELDS[row.field], row.value, row.status, ...row.candidates.map(value => value.value)]
      .some(value => value.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
  }), [rows, filters, query]);
  const { sortedRows, changeSort, directionFor } = useMultiColumnSort<LearnedRow, string>(filtered, (row, key) => {
    if (key === 'field') return LEARNING_FIELDS[row.field];
    const value = row[key as keyof LearnedRow];
    return typeof value === 'number' || typeof value === 'string' ? value : '';
  });
  const visibleColumns = columns.filter(column => column.visible);
  const minWidth = visibleColumns.reduce((sum, column) => sum + column.width, 136);
  const safePage = Math.min(page, Math.max(1, Math.ceil(sortedRows.length / TABLE_BATCH_SIZE)));
  useEffect(() => {
    const refresh = () => setStore(loadLearningStore());
    const storage = (event: StorageEvent) => { if (event.key === OCR_LEARNING_KEY || event.key === null) refresh(); };
    window.addEventListener(OCR_LEARNING_CHANGED, refresh); window.addEventListener('storage', storage);
    return () => { window.removeEventListener(OCR_LEARNING_CHANGED, refresh); window.removeEventListener('storage', storage); };
  }, []);
  useEffect(() => {
    if (!evidence && !forgetRow) return;
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') { setEvidence(null); setForgetRow(null); } };
    window.addEventListener('keydown', close); return () => window.removeEventListener('keydown', close);
  }, [evidence, forgetRow]);
  const act = (row: LearnedRow, action: 'pause' | 'resume' | 'forget') => {
    try {
      const changed = changeLearningState(row.id, action);
      setNotice(changed ? action === 'forget' ? 'Latest teaching source excluded. The document and audit history are retained.'
        : action === 'pause' ? 'Automatic filling paused for this client, supplier and field.' : 'Learning resumed. Confidence thresholds still apply.' : 'This action is not available for your permissions or the current record.');
      setForgetRow(null);
    } catch { setNotice('Changes could not be saved. Please try again.'); }
  };
  const renderCell = (row: LearnedRow, key: string) => {
    if (key === 'field') return LEARNING_FIELDS[row.field];
    if (key === 'status') return <LearningStatus row={row} />;
    if (key === 'consistency') return `${Math.round(row.consistency * 100)}%`;
    if (key === 'total') return `${row.count} of ${row.total}`;
    if (key === 'lastSeen') return dateTime(row.lastSeen);
    if (key === 'vatRate') return row.vatRate ? `${row.vatRate}%` : '—';
    if (key === 'companyName') return <span className="flex items-center gap-2"><span className="truncate" title={row.companyName}>{row.companyName}</span>{row.sample && <span className="shrink-0 rounded bg-[#E5EDF9] px-1.5 py-0.5 text-[10px] text-[#7288A3]" title="Demonstration only; never used to fill real documents">Example</span>}</span>;
    if (key === 'supplierKey') return <span className="block truncate" title={`${row.supplierName} · ${row.supplierKey}`}>{row.supplierKey.replace(/^name:/, '')}</span>;
    return String(row[key as keyof LearnedRow] || '—');
  };
  if (reviewDocument) return <WorkspaceDocumentEditor key={reviewDocument.documentId} documentId={reviewDocument.documentId} documentName={reviewDocument.documentName} onBack={() => setReviewDocument(null)} />;
  return <div className="flex h-dvh min-h-0 min-w-0 flex-col gap-3 overflow-hidden bg-white px-4 py-8 font-montserrat text-[#10233A] sm:gap-5 sm:px-8 sm:py-10 lg:px-[56px]">
    <PageHeader title="Machine learning" className="max-sm:[&_h1]:text-[24px]" actions={onOpenReviewQueue && <PageActionButton ariaLabel="Worker review queue" icon={<ListChecks size={16} className="shrink-0" />} className="max-sm:!w-8 max-sm:!px-0 max-sm:[&>span]:hidden" onClick={onOpenReviewQueue}>Worker review queue</PageActionButton>} />
    <OcrBreadcrumb items={['Machine learning']} />
    <div data-table-workspace-overview className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] px-4 py-3 text-[12px]">
      <span className="hidden lg:inline">What the system has learned, supplier by supplier.</span><span className="text-[#7288A3]">Automatic filling: <strong className="text-[#10233A]">2+ reviewed documents</strong> · <strong className="text-[#10233A]">90%+ agreement</strong></span>
    </div>
    <form onSubmit={event => { event.preventDefault(); setFilters({ ...draftFilters }); setPage(1); }} className="grid shrink-0 grid-cols-2 items-end gap-3 lg:flex lg:flex-wrap">
      <label className="flex min-w-0 flex-col gap-1.5 text-[12px] font-semibold lg:w-[190px]">Field<SearchableSelect ariaLabel="Learning field" value={draftFilters.field} options={[{ value: '', label: 'All' }, ...Object.entries(LEARNING_FIELDS).map(([value, label]) => ({ value, label }))]} onChange={field => setDraftFilters(current => ({ ...current, field }))} className={`${INPUT} pr-9 font-normal`} portalMenu /></label>
      <label className="flex min-w-0 flex-col gap-1.5 text-[12px] font-semibold lg:w-[190px]">Client<input aria-label="Learning client" className={INPUT} placeholder="Any client" value={draftFilters.client} onChange={event => setDraftFilters(current => ({ ...current, client: event.target.value }))} /></label>
      <label className="flex min-w-0 flex-col gap-1.5 text-[12px] font-semibold lg:w-[210px]">Supplier key<input aria-label="Learning supplier key" className={INPUT} placeholder="Any supplier" value={draftFilters.supplier} onChange={event => setDraftFilters(current => ({ ...current, supplier: event.target.value }))} /></label>
      <div className="flex items-center gap-2">
      <button type="submit" className="h-[38px] rounded-md border border-[#007EA7] bg-[#007EA7] px-4 text-[12px] font-semibold text-white hover:bg-[#006B8F]">Apply</button>
      <button type="button" onClick={() => { setDraftFilters(EMPTY_FILTERS); setFilters(EMPTY_FILTERS); setQuery(''); setPage(1); }} className="h-[38px] rounded-md border border-[#D3E1EC] px-4 text-[12px] font-semibold text-[#7288A3] hover:border-[#007EA7]">Reset</button>
      </div>
    </form>
    {notice && <div role="status" className="flex items-center justify-between gap-3 text-[12px] text-[#7288A3]"><span>{notice}</span><button aria-label="Close message" onClick={() => setNotice('')}><X size={14} /></button></div>}
    <div className="system-table-toolbar flex shrink-0 items-center gap-3"><OcrSearchField ariaLabel="Search learned values" value={query} onChange={value => { setQuery(value); setPage(1); }} /><div className="ml-auto flex h-7 shrink-0 items-center gap-4"><ColumnSettingsButton onClick={() => setShowColumns(true)} /><RefreshAllButton onRefresh={() => setStore(loadLearningStore())} /></div></div>
    <div ref={tableScrollRef} className="min-h-0 flex-1 overflow-auto overscroll-contain scrollbar-hide"><div style={{ minWidth }}>
      <div className="mb-1 flex h-10 items-center border-b border-[#D3E1EC] bg-white">{visibleColumns.map((column, index) => <div key={column.key} style={{ width: column.width }} className={`relative flex shrink-0 items-center gap-1 px-3 text-[12px] font-medium text-[#7288A3] ${index ? 'border-l border-[#D3E1EC]' : ''}`}><span className="truncate" title={column.label}>{column.label}</span><ColumnSortButton columnLabel={column.label} direction={directionFor(column.key)} onDirectionChange={direction => { changeSort(column.key, direction); setPage(1); }} /><ResizeHandle onMouseDown={event => startResize(columns.findIndex(item => item.key === column.key), event)} /></div>)}<div className="system-table-row-actions shrink-0" style={{ width: 136 }} /></div>
      {sortedRows.slice(0, safePage * TABLE_BATCH_SIZE).map((row, index) => {
        const allHistory = expandedHistory.has(row.id);
        const history = allHistory ? row.evidence : row.evidence.filter(item => item.active).slice(0, 2);
        return <section key={row.id} aria-label={`${row.companyName} · ${row.supplierName} · ${LEARNING_FIELDS[row.field]}`} className="mb-2">
          <div data-record-inactive={row.status === 'Inactive' || undefined} className={`flex h-11 items-center rounded-t-lg text-[12px] ${index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'} hover:bg-[#E7F4F9]`}>
            {visibleColumns.map(column => <div key={column.key} style={{ width: column.width }} className="shrink-0 overflow-hidden px-3"><span className="block truncate">{renderCell(row, column.key)}</span></div>)}
            <div className="system-table-row-actions flex shrink-0 items-center justify-end gap-2 px-2" style={{ width: 136 }}>
              <button type="button" disabled={!permissions.edit} aria-label={`${row.control?.paused ? 'Resume' : 'Pause'} ${row.supplierName} ${LEARNING_FIELDS[row.field]}`} onClick={() => act(row, row.control?.paused ? 'resume' : 'pause')} className="flex h-7 items-center gap-1 rounded border border-[#D3E1EC] bg-white px-2 text-[11px] font-medium text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7] disabled:opacity-40">{row.control?.paused ? <Play size={13} /> : <Pause size={13} />}{row.control?.paused ? 'Resume' : 'Pause'}</button>
              <RowDeleteButton linked disabled={!permissions.administrator || !permissions.edit || !row.total} label={`Delete latest teaching source for ${row.supplierName} ${LEARNING_FIELDS[row.field]}`} onDelete={() => setForgetRow(row)} />
            </div>
          </div>
          <div className="rounded-b-lg border-t border-[#E5EDF9] bg-[#F3F6FA] px-3 py-2 text-[11px] leading-5 text-[#7288A3]">
            {row.candidates.length > 1 && <div className="mb-1 flex items-center gap-2 text-[#9A6700]"><AlertTriangle size={13} /><span>Competing values:</span>{row.candidates.map(candidate => <span key={candidate.value} className="rounded bg-[#FFF8E5] px-2"><strong>{candidate.value}</strong> · {candidate.count} document{candidate.count === 1 ? '' : 's'}</span>)}</div>}
            <div className="flex items-center gap-3"><span className="font-semibold">Taught by · {row.total} reviewed document{row.total === 1 ? '' : 's'}</span><button type="button" onClick={() => setExpandedHistory(current => { const next = new Set(current); if (next.has(row.id)) next.delete(row.id); else next.add(row.id); return next; })} aria-expanded={allHistory} className="flex items-center gap-1 text-[#007EA7]">{allHistory ? 'Show less' : row.evidence.length > 2 ? `Show all ${row.evidence.length}` : 'History'}{allHistory ? <ChevronUp size={12} /> : <ChevronDown size={12} />}</button>{row.control && <span>{row.control.paused ? 'Paused' : 'Resumed'} by {row.control.changedBy.name} · {dateTime(row.control.changedAt)}</span>}</div>
            <div className="flex flex-wrap gap-x-5 gap-y-1">{history.map(item => <div key={item.id} data-record-inactive={!item.active || undefined}><strong className="text-[#10233A]">{item.value}</strong> — <button onClick={() => setEvidence(item)} className="text-[#007EA7] underline underline-offset-2">{item.documentName}</button>, confirmed by {item.confirmedBy.name} · {dateTime(item.confirmedAt)}{!item.active && <span> · {item.retirementReason} by {item.retiredBy?.name} · {item.retiredAt && dateTime(item.retiredAt)}</span>}</div>)}</div>
          </div>
        </section>;
      })}
      {!sortedRows.length && <div className="py-16 text-center text-[13px] text-[#7288A3]">No learned values match these filters.</div>}
    </div></div>
    <HorizontalTableScrollbar scrollRef={tableScrollRef} /><TablePagination currentPage={safePage} totalPages={Math.max(1, Math.ceil(sortedRows.length / TABLE_BATCH_SIZE))} itemCount={sortedRows.length} onPageChange={setPage} scrollRef={tableScrollRef} />
    {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={COLUMNS} onSave={next => { setColumns(next); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
    {(evidence || forgetRow) && <div className="fixed inset-0 z-[250] flex items-center justify-center bg-[#10233A]/30 p-4" onClick={() => { setEvidence(null); setForgetRow(null); }}><section role="dialog" aria-modal="true" aria-label={evidence ? 'Reviewed document' : 'Forget latest teaching source'} className="max-h-[85dvh] w-full max-w-[620px] overflow-auto rounded-xl border border-[#D3E1EC] bg-white p-6 shadow-xl" onClick={event => event.stopPropagation()}>
      <div className="mb-5 flex items-center justify-between gap-4"><h2 className="text-[20px] font-semibold">{evidence ? 'Reviewed document' : 'Forget latest teaching source'}</h2><button aria-label="Close dialog" onClick={() => { setEvidence(null); setForgetRow(null); }}><X size={20} /></button></div>
      {evidence ? <dl className="grid grid-cols-[150px_1fr] gap-x-4 gap-y-3 text-[13px]">{[['Document', evidence.documentName], ['Client', evidence.companyName], ['Supplier', evidence.supplierName], ['Supplier key', evidence.supplierKey], ['VAT rate', evidence.vatRate ? `${evidence.vatRate}%` : '—'], ['Field', LEARNING_FIELDS[evidence.field]], ['Confirmed value', evidence.value], ['Confirmed by', evidence.confirmedBy.name], ['Confirmed at', dateTime(evidence.confirmedAt)], ['Learning source', evidence.active ? 'Active' : `${evidence.retirementReason} · retained for audit`]].map(([label, value]) => <div className="contents" key={label}><dt className="text-[#7288A3]">{label}</dt><dd className="break-words font-medium">{value}</dd></div>)}{evidence.sample ? <p className="col-span-2 mt-3 rounded-lg bg-[#F8FDFF] p-3 text-[12px] text-[#7288A3]">Demonstration document. This example is not used to fill real documents.</p> : <div className="col-span-2 mt-3 flex justify-end"><PageActionButton onClick={() => { setReviewDocument(evidence); setEvidence(null); }}>Open document</PageActionButton></div>}</dl>
        : forgetRow && <><p className="text-[13px] leading-6 text-[#7288A3]">Exclude the latest confirmed document from learning for <strong className="text-[#10233A]">{forgetRow.supplierName} · {LEARNING_FIELDS[forgetRow.field]}</strong>? Confidence will be recalculated. The source document and its history will not be deleted.</p><div className="mt-6 flex justify-end gap-3"><button onClick={() => setForgetRow(null)} className="rounded-md border border-[#D3E1EC] px-4 py-2 text-[13px]">Cancel</button><button onClick={() => act(forgetRow, 'forget')} className="rounded-md bg-[#007EA7] px-4 py-2 text-[13px] font-semibold text-white">Exclude from learning</button></div></>}
    </section></div>}
  </div>;
}
