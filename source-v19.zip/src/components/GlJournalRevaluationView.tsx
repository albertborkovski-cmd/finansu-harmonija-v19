import { useMemo, useRef, useState } from 'react';
import { Calculator, Download, Eye } from 'lucide-react';
import { journalWorkingRows, type GlJournalRow } from '../lib/glJournal';
import type { JournalAccountOption, SavedJournalEntry } from '../lib/glJournalDrafts';
import { calculateRevaluation, journalRevaluationRates, monetaryAccount, revaluationResultRows, revaluationSelectableAccounts, type RevaluationLine, type RevaluationReport, type RevaluationResultRow } from '../lib/glJournalRevaluation';
import { usePersistentState } from '../hooks/usePersistentState';
import useAppTableFooterPosition from '../hooks/useAppTableFooterPosition';
import { PageActionButton, PageHeader } from './PageHeader';
import CompanyBreadcrumb from './CompanyBreadcrumb';
import ScheduleDatePicker from './ScheduleDatePicker';
import MultiSelectField from './MultiSelectField';
import OcrSearchField from './OcrSearchField';
import SystemAddFilters from './SystemAddFilters';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import { ColumnSettingsButton } from './ScopedActionButtons';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import RefreshAllButton from './RefreshAllButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import TablePagination from './TablePagination';
import GlJournalDialog from './GlJournalDialog';

const COLUMNS: ColConfig[] = [
  { key: 'period', label: 'Revaluation period', width: 175, visible: true },
  { key: 'account', label: 'GL account', width: 205, visible: true },
  { key: 'counterparty', label: 'Counterparty', width: 220, visible: false },
  { key: 'currency', label: 'Currency', width: 90, visible: true },
  { key: 'foreignMinor', label: 'Currency balance', width: 145, visible: true },
  { key: 'carryingMinor', label: 'Carrying value', width: 140, visible: true },
  { key: 'rate', label: 'Exchange rate', width: 140, visible: true },
  { key: 'rateDate', label: 'Rate date', width: 130, visible: false },
  { key: 'revaluedMinor', label: 'Revalued value', width: 145, visible: true },
  { key: 'differenceMinor', label: 'Difference', width: 125, visible: true },
  { key: 'debitAccount', label: 'Debit account', width: 165, visible: true },
  { key: 'creditAccount', label: 'Credit account', width: 165, visible: true },
  { key: 'documentNumbers', label: 'Source documents', width: 210, visible: false },
];
const money = (minor: number) => (minor / 100).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const accountLabel = (account: JournalAccountOption) => `${account.code} — ${account.name}`;
const today = () => { const date = new Date(); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; };
const fieldLabel = 'text-[12px] font-medium text-[#7288A3]';

export default function GlJournalRevaluationView({ companyId, companyName, baseCurrency, rows, accounts, savedEntries, testData, mayCreate, onRefresh, onSave, onOpenJournal }: {
  companyId: string; companyName: string; baseCurrency: string; rows: GlJournalRow[];
  accounts: JournalAccountOption[]; savedEntries: SavedJournalEntry[]; testData: boolean; mayCreate: boolean;
  onRefresh: () => void; onSave: (report: RevaluationReport) => string; onOpenJournal: (number: string) => void;
}) {
  const eligibleAccounts = useMemo(() => revaluationSelectableAccounts(accounts, journalWorkingRows(rows)), [accounts, rows]);
  // Retain old snapshots in history without adding their missing accounts to the choices.
  const latest = savedEntries.filter(entry => !entry.inactive && entry.revaluation?.accountCodes.every(code => eligibleAccounts.some(account => account.code === code))).at(-1)?.revaluation;
  const [date, setDate] = useState(latest?.date || today);
  const [selectedCodes, setSelected] = useState<string[]>(latest?.accountCodes || eligibleAccounts.filter(account => monetaryAccount(account) && rows.some(row => row.account === account.code && row.document.currency !== baseCurrency)).map(account => account.code));
  const selected = selectedCodes.filter(code => eligibleAccounts.some(account => account.code === code));
  const gainAccount = latest?.gainAccount || accounts.find(account => account.type === 'Income' && /exchange|valiut/i.test(account.name))?.code || '';
  const lossAccount = latest?.lossAccount || accounts.find(account => account.type === 'Expense' && /exchange|valiut/i.test(account.name))?.code || '';
  const [report, setReport] = useState<RevaluationReport | null>(latest || null);
  const [settingsChanged, setSettingsChanged] = useState(false);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [filterKeys, setFilterKeys] = useState<string[]>([]);
  const [filters, setFilters] = useState<Record<string, string[]>>({});
  const [storedColumns, setColumns] = usePersistentState<ColConfig[]>(`finansu-harmonija:v19:fx-revaluation-columns:${companyId}`, COLUMNS);
  const columns = useMemo(() => storedColumns.some(column => column.key === 'period') ? storedColumns : [COLUMNS[0], ...storedColumns], [storedColumns]);
  const [showColumns, setShowColumns] = useState(false);
  const [page, setPage] = useState(1);
  const [details, setDetails] = useState<RevaluationLine | null>(null);
  const tableRef = useRef<HTMLDivElement>(null);
  const totalsRef = useRef<HTMLDivElement>(null);
  const totalsPosition = useAppTableFooterPosition(totalsRef, 70);
  const { startResize } = useColumnResize(columns, setColumns);
  const visible = columns.filter(column => column.visible);
  const saved = report && savedEntries.find(entry => !entry.inactive && entry.revaluation?.fingerprint === report.fingerprint);
  const overlapsSaved = report && savedEntries.find(entry => !entry.inactive && entry.revaluation?.date === report.date && entry.revaluation.accountCodes.some(code => report.accountCodes.includes(code)));
  const total = report?.lines.reduce((sum, line) => sum + line.amountMinor, 0) || 0;
  const accountName = (code: string) => accounts.find(account => account.code === code)?.name || '';
  const rawValue = (line: RevaluationResultRow, key: string): string | number => key === 'documentNumbers' ? line.documentNumbers.join(', ') : key.endsWith('Minor') || key === 'rate' ? Number(line[key as keyof RevaluationResultRow]) : String(line[key as keyof RevaluationResultRow] ?? '');
  const displayValue = (line: RevaluationResultRow, key: string) => key === 'period' ? `${line.period} · As of ${line.revaluationDate}` : key.endsWith('Minor') ? money(Number(rawValue(line, key))) : key === 'rate' ? `${line.rate.toFixed(8)}` : rawValue(line, key) || '—';
  const resultRows = useMemo(() => revaluationResultRows(report), [report]);
  const filtered = useMemo(() => resultRows.filter(line =>
    [line.period, line.revaluationDate, line.account, line.accountName, line.counterparty, line.currency, ...line.documentNumbers].join(' ').toLocaleLowerCase().includes(query.toLocaleLowerCase()) &&
    filterKeys.every(key => !filters[key]?.length || filters[key].includes(String(rawValue(line, key))))
  ), [resultRows, query, filterKeys, filters]);
  const sorter = useMultiColumnSort<RevaluationResultRow, string>(filtered, rawValue);
  const changed = () => { setSettingsChanged(true); setDetails(null); setError(''); };
  const run = () => {
    setError(''); setDetails(null);
    let result: RevaluationReport | null = null;
    try {
      if (!mayCreate) throw new Error('You do not have permission to create journal entries for this company.');
      if (!gainAccount || !lossAccount) throw new Error('Configure exchange gain (Income) and exchange loss (Expense) accounts in the company accounting setup.');
      result = calculateRevaluation(rows, accounts, journalRevaluationRates(localStorage, testData), { date, baseCurrency, accountCodes: selected, gainAccount, lossAccount });
      setReport(result); setSettingsChanged(false); setQuery(''); setFilters({}); setFilterKeys([]); setPage(1);
      // A successful calculation saves once; invalid or zero adjustments never create an entry.
      if (!result.issues.length && result.lines.some(line => line.amountMinor > 0)) onSave(result);
    } catch (caught) { setReport(result); setError(caught instanceof Error ? caught.message : 'Revaluation could not be saved.'); }
  };
  const exportRows = () => {
    const lines = [visible.map(column => column.label), ...sorter.sortedRows.map(line => visible.map(column => String(displayValue(line, column.key))))];
    const url = URL.createObjectURL(new Blob(['\uFEFF' + lines.map(line => line.map(value => `"${value.replace(/"/g, '""')}"`).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = `exchange-rate-revaluation-${report?.date || date}.csv`; link.click(); URL.revokeObjectURL(url);
  };
  return <main className="flex h-screen min-w-0 flex-col gap-5 overflow-hidden bg-white py-14 font-montserrat text-[#10233A]" style={{ paddingLeft: 'clamp(24px, 5vw, 72px)', paddingRight: 'clamp(24px, 5vw, 72px)' }}>
    <PageHeader title="Exchange rate revaluation" />
    <CompanyBreadcrumb companyName={companyName} items={['GL journal', 'Exchange rate revaluation']} />
    <section aria-label="Revaluation settings" className="shrink-0 rounded-lg border border-[#D3E1EC] px-4 py-3">
      <div className="flex flex-wrap items-end gap-4">
        <div className="flex w-[190px] flex-col gap-2"><span className={fieldLabel}>Revaluation date <span className="text-[#FF4550]">*</span></span><ScheduleDatePicker value={date} onChange={value => { setDate(value); changed(); }} placeholder="YYYY-MM-DD" ariaLabel="Revaluation date" /></div>
        <div className="min-w-[240px] flex-1 [&>div>span]:text-[12px] [&>div>span]:font-medium [&>div>span]:text-[#7288A3]">
          <MultiSelectField label="GL accounts" required showSelectionActions options={eligibleAccounts.map(accountLabel)} value={selected.map(code => { const account = eligibleAccounts.find(item => item.code === code); return account ? accountLabel(account) : code; })} onChange={values => { setSelected(values.map(value => eligibleAccounts.find(account => accountLabel(account) === value)?.code || value)); changed(); }} placeholder="Select GL accounts" />
        </div>
        <PageActionButton icon={<Calculator size={15} />} disabled={!mayCreate || !date || !selected.length} onClick={run} className="mb-1">Run revaluation</PageActionButton>
      </div>
      {settingsChanged && report && <p role="status" className="mt-2 text-[11px] text-[#7288A3]">Settings changed · Run revaluation to update results</p>}
      {!eligibleAccounts.length && <p className="mt-2 text-[12px] text-[#7288A3]">No GL accounts found in this company’s journal.</p>}
    </section>
    {error && <p role="alert" className="shrink-0 text-[12px] text-[#C45100]">{error}</p>}
    {Boolean(report?.issues.length) && <details className="shrink-0 rounded-lg border border-[#F3D19E] bg-[#FFF8EC] px-3 py-2 text-[12px] text-[#7A4B00]"><summary className="cursor-pointer font-medium">{report!.issues.length} items need attention · journal creation is unavailable</summary><ul className="mt-2 max-h-28 list-inside list-disc overflow-auto">{report!.issues.map(issue => <li key={issue}>{issue}</li>)}</ul></details>}
    {!saved && overlapsSaved && <p className="shrink-0 text-[12px] text-[#7288A3]">A journal already exists for these accounts and this date: <button type="button" className="text-[#007EA7] underline" onClick={() => onOpenJournal(overlapsSaved.number)}>{overlapsSaved.number}</button></p>}
    <div className="flex shrink-0 flex-wrap items-center justify-between gap-3">
      <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1"><OcrSearchField ariaLabel="Search revaluation results" value={query} onChange={value => { setQuery(value); setPage(1); }} /><SystemAddFilters columns={COLUMNS.map(column => ({ key: column.key, label: column.label, options: [...new Set(resultRows.map(line => String(rawValue(line, column.key))))].filter(Boolean) }))} activeKeys={filterKeys} values={filters} onActiveKeysChange={value => { setFilterKeys(value); setPage(1); }} onValuesChange={value => { setFilters(value); setPage(1); }} /></div>
      <div data-table-workspace-tools className="ml-auto flex h-8 shrink-0 items-center gap-4">
        <ColumnSettingsButton onClick={() => setShowColumns(true)} />
        <button type="button" aria-label="EXPORT" title="EXPORT" data-button-family="export" disabled={!filtered.length} onClick={exportRows} className="text-[#7288A3] disabled:opacity-40"><Download size={16} /></button>
        <RefreshAllButton onRefresh={() => { changed(); onRefresh(); }} />
      </div>
    </div>
    <div ref={tableRef} className="min-h-0 flex-1 overflow-auto scrollbar-hide">
      <table aria-label="Exchange rate revaluation results" className="gl-journal-table w-full table-fixed border-separate border-spacing-0 text-[12px]" style={{ minWidth: visible.reduce((sum, column) => sum + column.width, 48) }}>
        <colgroup>{visible.map(column => <col key={column.key} style={{ width: column.width }} />)}<col /></colgroup>
        <thead><tr className="h-10">{visible.map(column => <th key={column.key} scope="col" className="relative border-b border-[#D3E1EC] bg-[#F8FDFF] py-2 pl-3 pr-5 text-left font-medium"><div className="flex items-center gap-1"><span>{column.label}{['carryingMinor', 'revaluedMinor', 'differenceMinor'].includes(column.key) && <span className="ml-1 text-[10px] text-[#7288A3]">{report?.baseCurrency || baseCurrency}</span>}</span><ColumnSortButton columnLabel={column.label} direction={sorter.directionFor(column.key)} onDirectionChange={direction => sorter.changeSort(column.key, direction)} /></div><ResizeHandle onMouseDown={event => startResize(columns.findIndex(item => item.key === column.key), event)} /></th>)}<th scope="col" aria-label="Row actions" className="border-b border-[#D3E1EC] bg-[#F8FDFF]" /></tr></thead>
        <tbody>{sorter.sortedRows.slice(0, page * 50).map((line, index) => <tr key={line.id} className={`h-11 hover:bg-[#E7F4F9] ${index % 2 ? 'bg-white' : 'bg-[#F8FDFF]'}`}>
          {visible.map(column => <td key={column.key} className="truncate px-3 py-1.5 tabular-nums" title={column.key === 'rate' ? `1 ${line.currency} = ${line.rate} ${report?.baseCurrency}; rate date ${line.rateDate}` : String(displayValue(line, column.key))}>
            {column.key === 'period' ? <><span className="font-medium">{line.period}</span><span className="block text-[10px] text-[#7288A3]">As of {line.revaluationDate}</span></> : column.key === 'account' ? <><span className="font-medium">{line.account}</span><span className="block truncate text-[10px] text-[#7288A3]">{line.counterparty || line.accountName}</span></> : ['debitAccount', 'creditAccount'].includes(column.key) ? <><span>{displayValue(line, column.key)}</span><span className="block truncate text-[10px] text-[#7288A3]">{accountName(String(rawValue(line, column.key)))}</span></> : column.key === 'rate' ? <><span>{displayValue(line, column.key)}</span><span className="block text-[10px] text-[#7288A3]">{report?.baseCurrency} / {line.currency}</span></> : column.key === 'differenceMinor' ? <span className={line.differenceMinor > 0 ? 'text-[#087A5B]' : line.differenceMinor < 0 ? 'text-[#C45100]' : 'text-[#7288A3]'}>{displayValue(line, column.key)}</span> : displayValue(line, column.key)}
          </td>)}
          <td className="system-table-row-actions px-2"><div className="flex items-center justify-end"><button type="button" title="View calculation" aria-label={`View calculation ${line.account} ${line.currency} ${line.counterparty}`.trim()} onClick={() => setDetails(line)} className="text-[#7288A3] hover:text-[#007EA7]"><Eye size={16} /></button></div></td>
        </tr>)}</tbody>
      </table>
      {!filtered.length && <div className="flex flex-col items-center gap-3 py-14 text-[13px] text-[#7288A3]"><Calculator size={24} /><p>{!report ? 'Select the date and GL accounts, then run revaluation.' : report.lines.length ? 'No matching records.' : report.issues.length ? 'Resolve the missing data to calculate these balances.' : 'No foreign-currency balances to revalue for this date.'}</p></div>}
    </div>
    <div ref={totalsRef} style={totalsPosition} aria-label="Revaluation totals" className="z-40 flex shrink-0 flex-wrap justify-between gap-3 bg-white text-[11px] text-[#7288A3]">{report && <><span>{report.date} · {report.lines.length} balances · {report.lines.filter(line => line.amountMinor).length} adjustments</span><span className="tabular-nums">Debit {money(total)} {report.baseCurrency} · Credit {money(total)} {report.baseCurrency}</span></>}</div>
    <HorizontalTableScrollbar scrollRef={tableRef} />
    <TablePagination scrollRef={tableRef} currentPage={page} totalPages={Math.max(1, Math.ceil(filtered.length / 50))} itemCount={filtered.length} itemsPerPage={50} onPageChange={setPage} />
    {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={COLUMNS} onSave={value => { setColumns(value); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
    {details && report && <GlJournalDialog title="Revaluation details" subtitle={`${details.account} · ${details.counterparty || details.accountName} · ${report.date}`} onClose={() => setDetails(null)} footer={<PageActionButton onClick={() => setDetails(null)}>Close</PageActionButton>}>
      <dl className="grid grid-cols-2 gap-x-5 gap-y-3 text-[12px]">{[
        ['Revaluation period', report.date.slice(0, 7)], ['Revaluation date', report.date],
        ['Currency balance', `${money(details.foreignMinor)} ${details.currency}`], ['Carrying value', `${money(details.carryingMinor)} ${report.baseCurrency}`],
        ['Exchange rate', `1 ${details.currency} = ${details.rate.toFixed(8)} ${report.baseCurrency}`], ['Rate date', details.rateDate],
        ['Revalued value', `${money(details.revaluedMinor)} ${report.baseCurrency}`], ['Difference', `${money(details.differenceMinor)} ${report.baseCurrency}`],
      ].map(([label, value]) => <div key={label}><dt className="mb-1 text-[#7288A3]">{label}</dt><dd className="font-medium tabular-nums">{value}</dd></div>)}</dl>
      <p className="mt-4 text-[11px] text-[#7288A3]">Balances use debit minus credit. The foreign-currency balance stays unchanged.</p>
      {details.amountMinor > 0 && <div className="mt-4 overflow-hidden rounded-lg border border-[#D3E1EC]"><table aria-label="Revaluation correspondence" className="w-full text-[12px]"><thead className="bg-[#F8FDFF]"><tr>{['GL account', `Debit, ${report.baseCurrency}`, `Credit, ${report.baseCurrency}`].map(label => <th key={label} className="px-3 py-2 text-left font-medium">{label}</th>)}</tr></thead><tbody><tr><td className="px-3 py-2">{details.debitAccount} — {accountName(details.debitAccount)}</td><td className="px-3 py-2">{money(details.amountMinor)}</td><td className="px-3 py-2">0.00</td></tr><tr><td className="px-3 py-2">{details.creditAccount} — {accountName(details.creditAccount)}</td><td className="px-3 py-2">0.00</td><td className="px-3 py-2">{money(details.amountMinor)}</td></tr></tbody></table></div>}
      <p className="mt-4 text-[12px] font-medium">Source documents</p><p className="mt-1 text-[12px] leading-6 text-[#7288A3]">{details.documentNumbers.join(', ')}</p>
    </GlJournalDialog>}
  </main>;
}
