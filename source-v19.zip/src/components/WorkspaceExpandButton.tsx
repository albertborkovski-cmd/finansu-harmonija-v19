import { Maximize2, Minimize2 } from 'lucide-react';

export default function WorkspaceExpandButton({ expanded, onClick }: { expanded: boolean; onClick: () => void }) {
  return <button type="button" data-button-family="workspace-expand"
    aria-label={expanded ? 'Exit full screen' : 'Expand workspace'}
    aria-pressed={expanded}
    title={expanded ? 'Exit full screen (Esc)' : 'Expand workspace'}
    onClick={onClick}
    className="flex h-4 w-4 shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#007EA7]">
    {expanded ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
  </button>;
}
