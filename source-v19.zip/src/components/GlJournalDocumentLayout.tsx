import { useEffect, useId, useRef, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { ChevronLeft, ChevronRight, FileText, FolderOpen, Printer, X } from 'lucide-react';
import { PageActionButton } from './PageHeader';
import useFrozenTableHeaders from '../hooks/useFrozenTableHeaders';

export const journalDocumentFieldClass = 'h-10 w-full min-w-0 truncate rounded-md border border-[#D3E1EC] bg-white px-3 text-[12px] font-medium text-[#10233A] outline-none focus:border-[#007EA7]';
export const journalDocumentFields = [
  ['counterparty', 'Counterparty', true], ['counterpartyCode', 'Counterparty code'], ['internalNumber', 'Internal No.'],
  ['number', 'Document No.'], ['documentDate', 'Document date'], ['operationDate', 'Operation date'], ['dueDate', 'Due date'],
  ['documentType', 'Document type'], ['operationType', 'Operation type'], ['account', 'GL account', true],
  ['currency', 'Currency'], ['exchangeRate', 'Exchange rate'], ['amount', 'Amount'], ['amountEur', 'Amount, EUR'],
  ['costCenter', 'Cost center'], ['object', 'Object'], ['department', 'Department'], ['employee', 'Employee'],
  ['vehicle', 'Vehicle'], ['createdBy', 'Created by'], ['status', 'Status'], ['matchedDocument', 'Matched document'], ['comment', 'Comment', true],
] as const;
export type JournalDocumentFieldKey = typeof journalDocumentFields[number][0];

export function JournalDocumentFields({ values, controls = {} }: {
  values: Partial<Record<JournalDocumentFieldKey, string>>;
  controls?: Partial<Record<JournalDocumentFieldKey, ReactNode>>;
}) {
  return <div className="grid grid-cols-2 gap-x-4 gap-y-4" aria-label="Document information">
    {journalDocumentFields.map(field => {
      const [key, label] = field;
      return <div key={key} data-journal-document-field={key} className={`flex min-w-0 flex-col gap-1.5 ${field[2] ? 'col-span-2' : ''}`}>
        <span className="text-[12px] font-medium text-[#7288A3]">{label}</span>
        {controls[key] ?? (key === 'comment'
          ? <textarea aria-label={label} readOnly value={values[key] || '—'} rows={3} className={`${journalDocumentFieldClass} h-auto resize-none py-2 leading-5`} />
          : <input aria-label={label} readOnly value={values[key] || '—'} title={values[key] || '—'} className={journalDocumentFieldClass} />)}
      </div>;
    })}
  </div>;
}

export function JournalEntryHeader({ side, status, index, count, onPrevious, onNext, action }: {
  side: string; status: string; index: number; count: number; onPrevious: () => void; onNext: () => void; action?: ReactNode;
}) {
  return <div className="mb-5 flex min-h-[56px] items-center justify-between gap-3 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] px-4 py-3">
    <div className="flex items-center gap-2"><FileText size={17} className="text-[#007EA7]" /><h3 className="text-[15px] font-semibold">{side}</h3></div>
    <div className="flex items-center gap-2">
      <span className={`rounded px-2 py-1 text-[11px] font-medium ${status === 'Posted' ? 'bg-[#E7F8F2] text-[#087A5B]' : 'bg-[#E5EDF9] text-[#7288A3]'}`}>{status}</span>
      <button type="button" aria-label="Previous GL entry" disabled={index <= 0} onClick={onPrevious} className="text-[#7288A3] hover:text-[#007EA7] disabled:opacity-30"><ChevronLeft size={16} /></button>
      <span className="whitespace-nowrap text-[11px] text-[#7288A3]">{count ? index + 1 : 0} / {count}</span>
      <button type="button" aria-label="Next GL entry" disabled={index >= count - 1} onClick={onNext} className="text-[#7288A3] hover:text-[#007EA7] disabled:opacity-30"><ChevronRight size={16} /></button>
      {action}
    </div>
  </div>;
}

export function JournalDocumentTotals({ totals, children }: { totals: { currency: string; debit: number; credit: number }[]; children?: ReactNode }) {
  const amount = (value: number) => value.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return <div className="rounded-lg border border-[#D3E1EC] px-4 py-4">
    <h3 className="mb-3 text-[12px] font-semibold">Document totals</h3>
    <div className="grid grid-cols-3 gap-3 text-[11px] text-[#7288A3]"><span>Currency</span><span className="text-right">Debit</span><span className="text-right">Credit</span></div>
    {totals.map(total => <div key={total.currency} className="mt-2 grid grid-cols-3 gap-3 text-[13px] font-medium tabular-nums"><span>{total.currency}</span><span className="text-right">{amount(total.debit)}</span><span className="text-right">{amount(total.credit)}</span></div>)}
    {children}
  </div>;
}

export function JournalCorrespondenceTable({ title, count, actions, editable = false, children }: {
  title: string; count: number; actions?: ReactNode; editable?: boolean; children: ReactNode;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);
  useFrozenTableHeaders(scrollRef, scrollRef);
  return <div className="overflow-hidden rounded-lg border border-[#D3E1EC]">
    <div className="flex min-h-[56px] items-center justify-between gap-3 border-b border-[#D3E1EC] bg-[#F8FDFF] px-4 py-3">
      <h3 className="text-[15px] font-semibold">{title}</h3>
      <div className="flex items-center gap-3"><span className="text-[11px] text-[#7288A3]">{count} {count === 1 ? 'line' : 'lines'}</span>{actions}</div>
    </div>
    <div ref={scrollRef} className="max-h-[48vh] overflow-auto">
      <table aria-label="Corresponding GL entries" className="gl-document-table w-full min-w-[790px] table-fixed border-separate border-spacing-0 text-[12px]">
        <colgroup><col style={{ width: 130 }} /><col style={{ width: 100 }} /><col style={{ width: 170 }} /><col style={{ width: 110 }} /><col style={{ width: 120 }} /><col />{editable && <col style={{ width: 40 }} />}</colgroup>
        <thead><tr>{['GL account', 'Amount', 'Counterparty', 'Amount, EUR', 'Matched document', 'Comment', ...(editable ? [''] : [])].map(label => <th scope="col" key={label} aria-label={label || 'Line actions'} className="border-b border-[#D3E1EC] bg-[#F8FDFF] px-3 py-3 text-left">{label}</th>)}</tr></thead>
        <tbody>{children}</tbody>
      </table>
      {!count && <p className="px-4 py-8 text-center text-[12px] text-[#7288A3]">No separate corresponding entries are available for this document.</p>}
    </div>
    <div className="flex justify-between gap-3 bg-[#F8FDFF] px-4 py-2 text-[11px] text-[#7288A3]"><span>Document correspondence</span><span>{count} {count === 1 ? 'record' : 'records'}</span></div>
  </div>;
}

export default function GlJournalDocumentLayout({ title, number, companyName, fileUrl, actions, details, correspondence, onClose }: {
  title: string; number: string; companyName: string; fileUrl?: string | null; actions?: ReactNode;
  details: ReactNode; correspondence: ReactNode; onClose: () => void;
}) {
  const titleId = useId();
  const dialogRef = useRef<HTMLElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const safeFileUrl = fileUrl && /^(https?:|blob:|data:application\/pdf[;,]|data:image\/)/i.test(fileUrl) ? fileUrl : null;
  useEffect(() => {
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    dialogRef.current?.focus();
    const handleKey = (event: KeyboardEvent) => {
      const dialog = dialogRef.current;
      if (!dialog) return;
      if (event.key === 'Escape') {
        if (dialog.querySelector('[role="combobox"][aria-expanded="true"]')) return;
        const calendar = dialog.querySelector<HTMLButtonElement>('button[aria-haspopup="dialog"][aria-expanded="true"]');
        event.preventDefault();
        if (calendar) { calendar.click(); calendar.focus(); return; }
        closeRef.current();
      }
      if (event.key !== 'Tab') return;
      const controls = Array.from(dialog.querySelectorAll<HTMLElement>('button:not(:disabled), a[href], input:not(:disabled), textarea:not(:disabled), [tabindex="0"]')).filter(element => element.getClientRects().length > 0);
      const first = controls[0]; const last = controls[controls.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || document.activeElement === dialog)) { event.preventDefault(); first?.focus(); }
    };
    window.addEventListener('keydown', handleKey, true);
    return () => { document.body.style.overflow = overflow; window.removeEventListener('keydown', handleKey, true); if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true }); };
  }, []);
  return createPortal(<div data-gl-document-overlay className="fixed inset-0 z-[240] flex items-center justify-center bg-[#10233A]/30 p-3 sm:p-6">
    <section ref={dialogRef} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="gl-document-dialog flex h-[min(900px,92vh)] w-full max-w-[1680px] flex-col overflow-hidden rounded-xl bg-white font-montserrat text-[#10233A] shadow-xl outline-none">
      <header className="flex shrink-0 flex-wrap items-center justify-between gap-4 border-b border-[#E5EDF9] px-6 py-5">
        <div className="min-w-0"><div className="mb-1 flex items-center gap-2 text-[11px] text-[#7288A3]"><span>{companyName}</span><span>/</span><span>GL journal</span></div><h2 id={titleId} className="truncate text-[22px] font-semibold">{title} <span className="font-normal text-[#7288A3]">·</span> {number}</h2></div>
        <div className="gl-document-actions flex items-center gap-2">
          {actions}
          {safeFileUrl && <a href={safeFileUrl} target="_blank" rel="noopener noreferrer" className="flex h-8 items-center gap-1.5 rounded-md border-2 border-[#D3E1EC] px-3 text-[12px] font-semibold text-[#7288A3] hover:border-[#A1B6C6]"><FolderOpen size={15} />Files</a>}
          <PageActionButton icon={<Printer size={15} />} onClick={() => window.print()}>Print</PageActionButton>
          <PageActionButton icon={<X size={15} />} onClick={onClose}>Close</PageActionButton>
        </div>
      </header>
      <div className="gl-document-content grid min-h-0 flex-1 grid-cols-1 gap-6 overflow-auto p-6 lg:grid-cols-[minmax(340px,0.85fr)_minmax(0,1.4fr)]">
        <section aria-label="Journal entry details" className="min-w-0">{details}</section>
        <section aria-label="Document correspondence" className="flex min-w-0 flex-col gap-4">{correspondence}</section>
      </div>
    </section>
  </div>, document.body);
}
