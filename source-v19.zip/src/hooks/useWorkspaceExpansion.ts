import { useLayoutEffect, type Dispatch, type SetStateAction } from 'react';

/** One fullscreen lifecycle for all record lists, including Reconciliation. */
export default function useWorkspaceExpansion(
  expanded: boolean,
  root: HTMLElement | null | undefined,
  setExpanded: Dispatch<SetStateAction<boolean>>,
) {
  useLayoutEffect(() => {
    if (!expanded || !root) return;
    const previousOverflow = document.body.style.overflow;
    const dialogScope = root.closest('[role="dialog"], [aria-modal="true"]');
    const belongsToWorkspace = (element: Element) => element.closest('[role="dialog"], [aria-modal="true"]') === dialogScope;
    const heading = [...root.querySelectorAll<HTMLElement>('[data-system-page-header]')].find(belongsToWorkspace);
    const hiddenChrome = [...root.querySelectorAll<HTMLElement>('[aria-label="Breadcrumb"], [data-system-breadcrumb], [data-table-workspace-overview]')].filter(belongsToWorkspace);
    const headingPath: HTMLElement[] = [];
    let headingParent = heading?.parentElement;
    while (headingParent && headingParent !== root) { headingPath.push(headingParent); headingParent = headingParent.parentElement; }
    heading?.setAttribute('data-expanded-workspace-heading', 'true');
    headingPath.forEach(element => element.setAttribute('data-expanded-workspace-heading-path', 'true'));
    hiddenChrome.forEach(element => element.setAttribute('data-expanded-workspace-hidden', 'true'));
    let viewport: HTMLElement | null = null;
    let path: HTMLElement[] = [];
    const scrollPositions = new Map<HTMLElement, { top: number; left: number }>();
    const rememberPosition = (element: HTMLElement) => {
      if (!scrollPositions.has(element)) scrollPositions.set(element, { top: element.scrollTop, left: element.scrollLeft });
    };
    rememberPosition(root);
    const syncViewport = () => {
      const next = [...root.querySelectorAll<HTMLElement>('[data-system-table-viewport]')].find(belongsToWorkspace) ?? null;
      if (next === viewport) return;
      viewport?.removeAttribute('data-expanded-table-viewport');
      path.forEach(element => element.removeAttribute('data-expanded-table-path'));
      viewport = next;
      path = [];
      let node = viewport?.parentElement;
      while (node && node !== root) { path.push(node); node = node.parentElement; }
      viewport?.setAttribute('data-expanded-table-viewport', 'true');
      [...path, ...(viewport ? [viewport] : [])].forEach(rememberPosition);
      path.forEach(element => element.setAttribute('data-expanded-table-path', 'true'));
    };
    root.setAttribute('data-table-workspace-expanded', 'true');
    syncViewport();
    // Switching a list tab may replace its viewport without closing the workspace.
    const observer = new MutationObserver(syncViewport);
    observer.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-system-table-viewport'] });
    document.body.style.overflow = 'hidden';
    const resize = () => window.dispatchEvent(new Event('resize'));
    resize();
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== 'Escape' || event.defaultPrevented) return;
      // Tree rows and expanded summaries are not popups and must not trap Esc.
      const overlays = document.querySelectorAll<HTMLElement>(
        '[role="dialog"], [aria-modal="true"], [data-column-settings-overlay], [role="listbox"], [role="menu"], [aria-haspopup][aria-expanded="true"]',
      );
      if ([...overlays].some(element => element.getClientRects().length && getComputedStyle(element).visibility !== 'hidden')) return;
      setExpanded(false);
    };
    document.addEventListener('keydown', onKey);
    return () => {
      observer.disconnect();
      root.removeAttribute('data-table-workspace-expanded');
      heading?.removeAttribute('data-expanded-workspace-heading');
      headingPath.forEach(element => element.removeAttribute('data-expanded-workspace-heading-path'));
      hiddenChrome.forEach(element => element.removeAttribute('data-expanded-workspace-hidden'));
      viewport?.removeAttribute('data-expanded-table-viewport');
      path.forEach(element => element.removeAttribute('data-expanded-table-path'));
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', onKey);
      resize();
      scrollPositions.forEach(({ top, left }, element) => {
        if (element !== viewport) element.scrollTop = top;
        element.scrollLeft = left;
      });
    };
  }, [expanded, root, setExpanded]);
}
