export type JournalClosingKind = 'classes56' | 'vat';
export type JournalClosingPeriod = { from: string; to: string };

export const JOURNAL_CLOSING_TITLES: Record<JournalClosingKind, string> = {
  classes56: 'Close classes 5 & 6',
  vat: 'VAT closing',
};

function isDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

export function closingPeriodError(period: JournalClosingPeriod): string {
  if (!period.from || !period.to) return 'Select both the start and end date.';
  if (!isDate(period.from) || !isDate(period.to)) return 'Select a valid date.';
  if (period.from > period.to) return 'The end date cannot be before the start date.';
  return '';
}

function storageKey(companyId: string, kind: JournalClosingKind) {
  return `finansu-harmonija:v19:gl-closing-period:${encodeURIComponent(companyId)}:${kind}`;
}

export function loadClosingPeriod(storage: Pick<Storage, 'getItem'>, companyId: string, kind: JournalClosingKind): JournalClosingPeriod | null {
  try {
    const saved: unknown = JSON.parse(storage.getItem(storageKey(companyId, kind)) || 'null');
    if (!saved || typeof saved !== 'object' || !('from' in saved) || !('to' in saved) || typeof saved.from !== 'string' || typeof saved.to !== 'string') return null;
    const period = { from: saved.from, to: saved.to };
    return closingPeriodError(period) ? null : period;
  } catch {
    return null;
  }
}

/** Stores a period selection only, not an executed close or accounting posting. */
export function saveClosingPeriod(storage: Pick<Storage, 'setItem'>, companyId: string, kind: JournalClosingKind, period: JournalClosingPeriod) {
  const error = closingPeriodError(period);
  if (error) throw new Error(error);
  storage.setItem(storageKey(companyId, kind), JSON.stringify({ from: period.from, to: period.to }));
}
