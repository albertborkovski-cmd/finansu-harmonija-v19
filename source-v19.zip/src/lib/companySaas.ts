export type CompanySaasPlan = {
  produktas: 'ocr' | 'panel' | 'both';
  kainodara: 'docs' | 'users' | 'fixed';
  kiekis: string;
  kaina: string;
  periodas: 'month' | 'year';
  virsijimas: 'charge' | 'block';
  moduliai: Array<'email' | 'sharepoint' | 'dropbox' | 'google_drive' | 'api' | 'rivile_export'>;
};

export const SAAS_PRODUCTS = [
  { value: 'ocr', label: 'OCR' },
  { value: 'panel', label: 'Panel' },
  { value: 'both', label: 'OCR + Panel' },
];
export const SAAS_PRICING = [
  { value: 'docs', label: 'Per document' },
  { value: 'users', label: 'Per active user' },
  { value: 'fixed', label: 'Fixed fee per company' },
];
export const SAAS_MODULES = [
  { value: 'email', label: 'Email document collection' },
  { value: 'sharepoint', label: 'SharePoint' },
  { value: 'dropbox', label: 'Dropbox' },
  { value: 'google_drive', label: 'Google Drive' },
  { value: 'api', label: 'API integrations' },
  { value: 'rivile_export', label: 'Rivilė export' },
] as const;
export const SAAS_PERIODS = [
  { value: 'month', label: 'Monthly' },
  { value: 'year', label: 'Yearly' },
];
export const SAAS_OVERAGE = [
  { value: 'charge', label: 'Charge for extra documents' },
  { value: 'block', label: 'Stop at the limit' },
];

export function defaultCompanySaasPlan(): CompanySaasPlan {
  return { produktas: 'both', kainodara: 'docs', kiekis: '5000', kaina: '0.08', periodas: 'month', virsijimas: 'charge', moduliai: ['email', 'api'] };
}

/** Accepts the supplied JSON shape as well as the persisted company field. */
export function parseCompanySaasPlan(raw: unknown): CompanySaasPlan {
  const defaults = defaultCompanySaasPlan();
  try {
    const value = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)) return defaults;
    const candidate = value as Record<string, unknown>;
    const modules = candidate.moduliai;
    return {
      produktas: SAAS_PRODUCTS.some(option => option.value === candidate.produktas) ? candidate.produktas as CompanySaasPlan['produktas'] : defaults.produktas,
      kainodara: SAAS_PRICING.some(option => option.value === candidate.kainodara) ? candidate.kainodara as CompanySaasPlan['kainodara'] : defaults.kainodara,
      kiekis: /^[1-9]\d*$/.test(String(candidate.kiekis)) && Number.isSafeInteger(Number(candidate.kiekis)) ? String(candidate.kiekis) : defaults.kiekis,
      kaina: /^(?:0|[1-9]\d*)(?:\.\d{1,6})?$/.test(String(candidate.kaina)) && Number.isFinite(Number(candidate.kaina)) ? String(candidate.kaina) : defaults.kaina,
      periodas: candidate.periodas === 'year' ? 'year' : 'month',
      virsijimas: candidate.virsijimas === 'block' ? 'block' : 'charge',
      moduliai: Array.isArray(modules) ? SAAS_MODULES.filter(module => modules.includes(module.value)).map(module => module.value) : defaults.moduliai,
    };
  } catch { return defaults; }
}

export function validateCompanySaasPlan(plan: CompanySaasPlan): string | null {
  if (!SAAS_PRODUCTS.some(option => option.value === plan.produktas) || !SAAS_PRICING.some(option => option.value === plan.kainodara)
    || !SAAS_PERIODS.some(option => option.value === plan.periodas) || !SAAS_OVERAGE.some(option => option.value === plan.virsijimas)) return 'Select valid SaaS plan options.';
  if (!/^[1-9]\d*$/.test(plan.kiekis) || !Number.isSafeInteger(Number(plan.kiekis))) return 'Document limit must be a positive whole number.';
  if (!/^(?:0|[1-9]\d*)(?:\.\d{1,6})?$/.test(plan.kaina) || !Number.isFinite(Number(plan.kaina))) return 'Enter a valid non-negative price (up to 6 decimal places).';
  if (plan.moduliai.some(value => !SAAS_MODULES.some(module => module.value === value))) return 'Select valid SaaS modules.';
  return null;
}

function localDateKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

/** Receive dates can be ISO dates/timestamps or the existing DD.MM.YYYY display format. */
function receivedDateKey(raw: unknown): string {
  if (typeof raw !== 'string') return '';
  const value = raw.trim();
  if (/^\d{4}-\d{2}-\d{2}T/.test(value)) {
    const timestamp = new Date(value);
    return Number.isFinite(timestamp.getTime()) ? localDateKey(timestamp) : '';
  }
  const dotted = value.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  const key = dotted ? `${dotted[3]}-${dotted[2]}-${dotted[1]}` : value;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return '';
  const date = new Date(`${key}T12:00:00`);
  return Number.isFinite(date.getTime()) && localDateKey(date) === key ? key : '';
}

export type SaasUsageDocument = { id?: unknown; company_id?: unknown; receive_date?: unknown; created_at?: unknown };

export function companySaasUsage(companyId: string, documents: SaasUsageDocument[], plan: CompanySaasPlan, now = new Date()) {
  const today = localDateKey(now);
  const from = plan.periodas === 'year' ? `${now.getFullYear()}-01-01` : `${today.slice(0, 7)}-01`;
  const to = localDateKey(new Date(now.getFullYear(), plan.periodas === 'year' ? 12 : now.getMonth() + 1, 0));
  const ids = new Set<string>();
  for (const row of documents) {
    if (!companyId || row.company_id !== companyId || typeof row.id !== 'string' || !row.id.trim()) continue;
    const date = receivedDateKey(row.receive_date || row.created_at);
    if (date && date >= from && date <= today) ids.add(row.id);
  }
  const limit = Number(plan.kiekis);
  const validLimit = Number.isSafeInteger(limit) && limit > 0;
  const used = ids.size;
  return {
    from, to, used,
    remaining: validLimit ? Math.max(0, limit - used) : null,
    exceeded: validLimit ? Math.max(0, used - limit) : 0,
    percentage: validLimit ? Math.round((used / limit) * 1000) / 10 : null,
    progress: validLimit ? Math.min(100, used / limit * 100) : 0,
  };
}
