import { supabase, type Company, type DbDocument } from './supabase';

export async function loadOcrOrganizations(): Promise<Company[]> {
  const result = await supabase.from('companies').select('*').order('name', { ascending: true });
  return (result.data ?? []) as unknown as Company[];
}

/** Shared source for OCR processed documents and uploaded-document assignment. */
export async function loadOcrDocumentSource() {
  const [organizations, documentResult] = await Promise.all([
    loadOcrOrganizations(),
    supabase.from('documents').select('*').order('receive_date', { ascending: false }),
  ]);
  return {
    organizations,
    documents: (documentResult.data ?? []) as unknown as DbDocument[],
  };
}
