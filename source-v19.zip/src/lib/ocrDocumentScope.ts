/** Legacy uploaded files are stored by company name. Never fall back to all companies. */
export function documentsForOcrOrganization<T extends { organizationName?: string }>(
  records: readonly T[],
  organization: { id: string; name: string } | null | undefined,
): T[] {
  if (!organization?.id || !organization.name) return [];
  return records.filter((record) => record.organizationName === organization.name);
}
