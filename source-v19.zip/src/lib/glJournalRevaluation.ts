import type { GlJournalRow } from './glJournal';
import type { JournalAccountOption, JournalDraft } from './glJournalDrafts';

export type RevaluationRate = { id: string; code: string; date: string; quantity: number; rate: number };
export type RevaluationLine = {
  id: string; account: string; accountName: string; counterparty: string; currency: string;
  foreignMinor: number; carryingMinor: number; revaluedMinor: number; differenceMinor: number;
  rate: number; rateDate: string; debitAccount: string; creditAccount: string; amountMinor: number;
  sourceIds: string[]; documentNumbers: string[];
};
export type RevaluationReport = {
  date: string; baseCurrency: string; accountCodes: string[]; gainAccount: string; lossAccount: string;
  lines: RevaluationLine[]; issues: string[]; fingerprint: string;
};
export type RevaluationResultRow = RevaluationLine & { period: string; revaluationDate: string };

export function revaluationResultRows(report: RevaluationReport | null): RevaluationResultRow[] {
  // Derive display metadata from the calculated snapshot, never the editable form date.
  return report ? report.lines.map(line => ({ ...line, period: report.date.slice(0, 7), revaluationDate: report.date })) : [];
}
export const REVALUATION_RATE_KEY = 'finansu-harmonija:v19:exchange-rates';
export const SAMPLE_MONETARY_TYPES: Record<string, string> = { '2410': 'Receivable', '4430': 'Payable', '4431': 'Payable', '2710': 'Bank & Cash' };
export const SAMPLE_FX_ACCOUNTS: JournalAccountOption[] = [
  { code: '5800', name: 'Foreign exchange gains', type: 'Income' },
  { code: '6800', name: 'Foreign exchange losses', type: 'Expense' },
];
// Deliberately separate from Settings rates; these belong to test journal records only.
export const SAMPLE_REVALUATION_RATES: RevaluationRate[] = [
  ['2026-08-01', 1.08], ['2026-09-01', 1.10], ['2026-10-01', 1.12],
  ['2026-10-19', 1.16], ['2026-10-31', 1.14],
].map(([date, rate]) => ({ id: `test-usd-${date}`, code: 'USD', date: String(date), quantity: 1, rate: Number(rate) }));

export function revaluationDateValid(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
export function monetaryAccount(account: JournalAccountOption) {
  return ['Receivable', 'Payable', 'Bank & Cash'].includes(account.type || '');
}
export function revaluationSelectableAccounts(accounts: JournalAccountOption[], rows: GlJournalRow[]) {
  // The company journal is the source of choices; the chart only supplies metadata.
  const chart = new Map(accounts.map(account => [account.code, account]));
  const used = new Map<string, JournalAccountOption>();
  for (const row of rows) {
    const code = row.account.trim();
    if (!code || code === '—' || used.has(code)) continue;
    used.set(code, chart.get(code) || { code, name: row.accountName || code });
  }
  return [...used.values()].sort((a, b) => a.code.localeCompare(b.code, undefined, { numeric: true }));
}
export function readRevaluationRates(storage: Pick<Storage, 'getItem'>): RevaluationRate[] {
  const value: unknown = JSON.parse(storage.getItem(REVALUATION_RATE_KEY) || '[]');
  if (!Array.isArray(value)) throw new Error('Exchange rates could not be read. Review Settings → General settings → Exchange rates.');
  return value as RevaluationRate[];
}
export function journalRevaluationRates(storage: Pick<Storage, 'getItem'>, testData: boolean) {
  const configured = readRevaluationRates(storage);
  // A configured currency always wins, including a missing/invalid closing rate.
  // Samples fill only currencies for which the demo has no Settings rate at all.
  return testData ? [...configured, ...SAMPLE_REVALUATION_RATES.filter(rate => !configured.some(saved => saved?.code === rate.code))] : configured;
}

/** Settings convention: quantity EUR = rate currency units. Never use future rates. */
function currencyPerEuro(rates: RevaluationRate[], currency: string, date: string) {
  if (currency === 'EUR') return { value: 1, date };
  const eligible = rates.filter(rate => rate && rate.code === currency && revaluationDateValid(rate.date) && rate.date <= date);
  const latestDate = eligible.map(rate => rate.date).sort().at(-1);
  const latest = eligible.filter(rate => rate.date === latestDate);
  if (!latest.length) throw new Error(`${currency}: no exchange rate on or before ${date}.`);
  if (latest.some(rate => !Number.isFinite(rate.rate) || rate.rate <= 0 || !Number.isFinite(rate.quantity) || rate.quantity <= 0)) throw new Error(`${currency}: invalid exchange rate for ${latestDate}.`);
  const values = new Set(latest.map(rate => rate.rate / rate.quantity));
  if (values.size !== 1) throw new Error(`${currency}: conflicting exchange rates for ${latestDate}.`);
  return { value: latest[0].rate / latest[0].quantity, date: latest[0].date };
}
export function revaluationRate(rates: RevaluationRate[], currency: string, baseCurrency: string, date: string) {
  const foreign = currencyPerEuro(rates, currency, date);
  const base = currencyPerEuro(rates, baseCurrency, date);
  return { value: base.value / foreign.value, date: baseCurrency === 'EUR' ? foreign.date : `${foreign.date} / ${base.date}` };
}
function minor(value: number | undefined) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) return null;
  const result = Math.round(value * 100);
  return Number.isSafeInteger(result) ? result : null;
}

export function calculateRevaluation(rows: GlJournalRow[], accounts: JournalAccountOption[], rates: RevaluationRate[], settings: {
  date: string; baseCurrency: string; accountCodes: string[]; gainAccount: string; lossAccount: string;
}): RevaluationReport {
  if (!revaluationDateValid(settings.date)) throw new Error('Select a valid revaluation date.');
  if (!/^[A-Z]{3}$/.test(settings.baseCurrency)) throw new Error('Configure the company base currency.');
  const selected = [...new Set(settings.accountCodes)].sort();
  if (!selected.length) throw new Error('Select at least one GL account.');
  if (selected.some(code => !accounts.some(account => account.code === code && monetaryAccount(account)))) throw new Error('Select active Receivable, Payable or Bank & Cash accounts.');
  if (!accounts.some(account => account.code === settings.gainAccount && account.type === 'Income') || !accounts.some(account => account.code === settings.lossAccount && account.type === 'Expense')) throw new Error('Select an Income account for exchange gains and an Expense account for exchange losses.');
  if (settings.gainAccount === settings.lossAccount || selected.includes(settings.gainAccount) || selected.includes(settings.lossAccount)) throw new Error('Correspondence accounts must be different from the revalued accounts.');

  const groups = new Map<string, { account: JournalAccountOption; currency: string; counterparty: string; rows: GlJournalRow[] }>();
  const issues: string[] = [];
  const relevant = rows.filter(row => !row.inactive && row.posted && selected.includes(row.account) && row.document.currency !== settings.baseCurrency);
  for (const row of relevant) {
    const date = row.operationDate.slice(0, 10);
    if (!revaluationDateValid(date)) { issues.push(`${row.documentNumber}: invalid posting date.`); continue; }
    if (date > settings.date) continue;
    const account = accounts.find(item => item.code === row.account)!;
    const counterparty = account.type === 'Bank & Cash' ? '' : row.counterparty === '—' ? '' : row.counterparty;
    const key = JSON.stringify([row.account, row.document.currency, counterparty]);
    const group = groups.get(key) || { account, currency: row.document.currency, counterparty, rows: [] };
    group.rows.push(row); groups.set(key, group);
  }
  const lines: RevaluationLine[] = [];
  for (const [id, group] of groups) {
    let foreignMinor = 0, carryingMinor = 0;
    const groupIssues: string[] = [];
    for (const row of group.rows) {
      const debit = minor(row.debit), credit = minor(row.credit), baseDebit = minor(row.baseDebit), baseCredit = minor(row.baseCredit);
      if (!row.accountActive || !row.balanced || debit === null || credit === null || (debit > 0 && credit > 0)) {
        groupIssues.push(`${row.documentNumber}: review the source GL posting.`); continue;
      }
      if (row.baseCurrency !== settings.baseCurrency || baseDebit === null || baseCredit === null) {
        groupIssues.push(`${row.documentNumber}: booked ${settings.baseCurrency} amounts are missing.`); continue;
      }
      foreignMinor += debit - credit; carryingMinor += baseDebit - baseCredit;
    }
    if (groupIssues.length) { issues.push(...groupIssues); continue; }
    if (!Number.isSafeInteger(foreignMinor) || !Number.isSafeInteger(carryingMinor)) { issues.push(`${group.account.code}: balance exceeds the supported amount.`); continue; }
    if (!foreignMinor && !carryingMinor) continue;
    try {
      const rate = revaluationRate(rates, group.currency, settings.baseCurrency, settings.date);
      const revaluedMinor = Math.sign(foreignMinor) * Math.round(Math.abs(foreignMinor) * rate.value);
      const differenceMinor = revaluedMinor - carryingMinor;
      if (!Number.isSafeInteger(revaluedMinor) || !Number.isSafeInteger(differenceMinor)) throw new Error(`${group.account.code}: revalued balance exceeds the supported amount.`);
      lines.push({ id, account: group.account.code, accountName: group.account.name, counterparty: group.counterparty, currency: group.currency,
        foreignMinor, carryingMinor, revaluedMinor, differenceMinor, rate: rate.value, rateDate: rate.date,
        debitAccount: differenceMinor > 0 ? group.account.code : differenceMinor < 0 ? settings.lossAccount : '',
        creditAccount: differenceMinor > 0 ? settings.gainAccount : differenceMinor < 0 ? group.account.code : '', amountMinor: Math.abs(differenceMinor),
        sourceIds: group.rows.map(row => row.id).sort(), documentNumbers: [...new Set(group.rows.map(row => row.documentNumber))].sort(),
      });
    } catch (error) { issues.push(error instanceof Error ? error.message : 'Exchange rate is unavailable.'); }
  }
  lines.sort((a, b) => a.account.localeCompare(b.account) || a.currency.localeCompare(b.currency) || a.counterparty.localeCompare(b.counterparty));
  const result = { date: settings.date, baseCurrency: settings.baseCurrency, gainAccount: settings.gainAccount, lossAccount: settings.lossAccount, accountCodes: selected, lines, issues: [...new Set(issues)] };
  // Snapshot, not a floating-point hash: saving checks the full calculation again.
  return { ...result, fingerprint: JSON.stringify(result) };
}

export function revaluationDraft(report: RevaluationReport, number: string): JournalDraft {
  if (report.issues.length) throw new Error('Resolve the missing data and run the calculation again before creating a journal entry.');
  const adjustments = report.lines.filter(line => line.amountMinor > 0);
  if (!adjustments.length) throw new Error('There are no exchange differences to save.');
  return { number, date: report.date, currency: report.baseCurrency, copiedFromId: `fx-revaluation:${report.date}`, note: `Exchange rate revaluation · ${report.date}`,
    lines: adjustments.flatMap((line, index) => {
      const comment = `${line.account} · ${line.currency} ${(line.foreignMinor / 100).toFixed(2)} · ${(line.carryingMinor / 100).toFixed(2)} → ${(line.revaluedMinor / 100).toFixed(2)} ${report.baseCurrency} · rate ${line.rate.toFixed(8)} (${line.rateDate})`;
      const common = { counterparty: line.counterparty, costCenter: '', comment };
      return [{ ...common, id: `fx-${index}-debit`, account: line.debitAccount, debit: (line.amountMinor / 100).toFixed(2), credit: '' },
        { ...common, id: `fx-${index}-credit`, account: line.creditAccount, debit: '', credit: (line.amountMinor / 100).toFixed(2) }];
    }),
  };
}
