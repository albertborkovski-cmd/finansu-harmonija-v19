import { journalMatchesPeriod, type GlJournalRow } from './glJournal';
import { closingPeriodError, type JournalClosingPeriod } from './glJournalClosing';

/** Posted active movements only; never combine currencies or imply a tax declaration. */
export function journalVatMovements(rows: GlJournalRow[], period: JournalClosingPeriod, accounts: string[]) {
  if (closingPeriodError(period)) return [];
  const selected = new Set(accounts.filter(Boolean));
  const totals = new Map<string, { account: string; currency: string; debitMinor: number; creditMinor: number; documents: Set<string> }>();
  rows.filter(row => row.posted && row.balanced && !row.inactive && selected.has(row.account) && journalMatchesPeriod(row, period)).forEach(row => {
    const currency = row.document.currency || 'EUR';
    const key = JSON.stringify([row.account, currency]);
    const total = totals.get(key) || { account: row.account, currency, debitMinor: 0, creditMinor: 0, documents: new Set<string>() };
    total.debitMinor += Math.round(row.debit * 100); total.creditMinor += Math.round(row.credit * 100); total.documents.add(row.document.id);
    totals.set(key, total);
  });
  return [...totals.values()].map(total => ({ ...total, documents: total.documents.size })).sort((a, b) => a.account.localeCompare(b.account) || a.currency.localeCompare(b.currency));
}

export type VatEmailPurpose = 'confirmation' | 'information';

/** Period movement estimate, not a declaration or a remaining tax-debt balance. */
export function journalVatCalculation(rows: GlJournalRow[], period: JournalClosingPeriod, accounts: string[]) {
  if (!accounts[0] || !accounts[1] || accounts[0] === accounts[1]) return { error: 'Select two different input and output VAT accounts.', amounts: [] };
  const eligible = rows.filter(row => row.posted && row.balanced && !row.inactive && accounts.includes(row.account) && journalMatchesPeriod(row, period));
  if (eligible.some(row => row.debit > 0 && row.credit > 0)) return { error: 'Separate debit and credit postings are required to calculate VAT. Review the source GL entries.', amounts: [] };
  const movements = journalVatMovements(rows, period, accounts);
  const currencies = [...new Set(movements.map(row => row.currency))];
  const amounts = currencies.map(currency => {
    const input = movements.find(row => row.account === accounts[0] && row.currency === currency);
    const output = movements.find(row => row.account === accounts[1] && row.currency === currency);
    const inputMinor = (input?.debitMinor || 0) - (input?.creditMinor || 0);
    const outputMinor = (output?.creditMinor || 0) - (output?.debitMinor || 0);
    return { currency, inputMinor, outputMinor, payableMinor: Math.max(0, outputMinor - inputMinor), recoverableMinor: Math.max(0, inputMinor - outputMinor) };
  });
  return { error: closingPeriodError(period), amounts };
}

export function journalVatEmail(company: string, period: JournalClosingPeriod, accounts: string[], rows: GlJournalRow[], options: {
  purpose?: VatEmailPurpose; contactName?: string; message?: string;
} = {}) {
  const totals = journalVatMovements(rows, period, accounts);
  const confirmation = (options.purpose || 'confirmation') === 'confirmation';
  const subject = `${confirmation ? 'VAT reconciliation — confirmation requested' : 'VAT reconciliation information'} · ${company.replace(/[\r\n]/g, ' ')} · ${period.from} — ${period.to}`;
  const body = [
    options.contactName?.trim() ? `Hello ${options.contactName.trim()},` : 'Hello,',
    '', confirmation
      ? 'Please review the VAT account summary below and reply to confirm whether it agrees with your records. If there are differences or missing documents, please describe them in your reply.'
      : 'Please find the VAT account summary for the period below. Please reply if any corrections or additional documents are needed.',
    '',
    `Company: ${company}`, `Period: ${period.from} — ${period.to}`, `GL accounts: ${accounts.filter(Boolean).join(', ')}`,
    '', 'Posted, active VAT account movements:',
    ...totals.map(total => `${total.account} · ${total.currency} · Debit ${(total.debitMinor / 100).toFixed(2)} · Credit ${(total.creditMinor / 100).toFixed(2)} · ${total.documents} documents`),
    '', 'Currencies are shown separately. Inactive and unposted entries are excluded.',
    'This is a GL movement summary, not a VAT declaration or confirmation of posted closing entries.',
    ...(options.message?.trim() ? ['', options.message.trim()] : []),
    '', confirmation ? 'Thank you. We look forward to your confirmation or comments.' : 'Thank you.',
  ].join('\r\n');
  return { subject, body, totals };
}

export function journalMailto(recipient: string, subject: string, body: string) {
  const email = recipient.trim();
  if (!/^[^\s@?,;&\r\n]+@[^\s@?,;&\r\n]+\.[^\s@?,;&\r\n]+$/.test(email)) throw new Error('Enter a valid recipient email address.');
  return `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
