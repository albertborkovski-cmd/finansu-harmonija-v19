import { deactivateRecord } from './recordLifecycle';
import { editJournalDraft, journalDraftStorageKey, loadJournalDrafts, type JournalSourceMode, type SavedJournalEntry } from './glJournalDrafts';
import type { GlJournalRow } from './glJournal';

/** Preserve the whole balanced entry and its source identity. Never delete individual posted lines. */
export function deactivateJournalDocument(storage: Pick<Storage, 'getItem' | 'setItem'>, context: {
  companyId: string; mode: JournalSourceMode; id: string; expectedRevision: number | null; changedAt: string; changedBy: string;
}, source: GlJournalRow[]) {
  const saved = loadJournalDrafts(storage, context.companyId, context.mode);
  const previous = saved.find(entry => entry.id === context.id);
  if (previous?.inactive) return previous;
  if ((previous ? previous.revision || 0 : null) !== context.expectedRevision) throw new Error('This entry changed in another window. Reopen it before deactivating.');
  const rows = source.filter(row => row.document.id === context.id);
  if (!previous && (context.mode !== 'test' || !rows.length || rows.some(row => !row.sample))) throw new Error('Manage this operation in its source document.');
  const first = rows[0];
  const original: SavedJournalEntry = previous || {
    id: context.id, companyId: context.companyId, sourceMode: context.mode, sourceDocumentId: context.id,
    number: first.documentNumber, date: first.operationDate, currency: first.document.currency, note: first.document.note || '',
    status: 'Draft', createdAt: first.createdAt || context.changedAt, createdBy: first.createdBy || '—',
    lines: rows.map(row => ({ id: row.id, account: row.account, accountName: row.accountName || row.account,
      counterparty: row.counterparty, costCenter: row.costCenter, object: row.object || '', department: row.department || '', employee: row.employee || '', vehicle: row.vehicle || '',
      debitMinor: Math.round(row.debit * 100), creditMinor: Math.round(row.credit * 100), comment: row.description || '' })),
  };
  // Apply the shared lifecycle marker without changing the historical posting status.
  const entry: SavedJournalEntry = { ...original, ...deactivateRecord({ inactive: false }),
    revision: (original.revision || 0) + 1, updatedAt: context.changedAt, updatedBy: context.changedBy,
    deactivatedAt: context.changedAt, deactivatedBy: context.changedBy,
    history: [...original.history || [], { changedAt: context.changedAt, changedBy: context.changedBy, before: editJournalDraft(rows, context.id) }],
  };
  storage.setItem(journalDraftStorageKey(context.companyId, context.mode), JSON.stringify(previous ? saved.map(item => item.id === entry.id ? entry : item) : [...saved, entry]));
  return entry;
}
